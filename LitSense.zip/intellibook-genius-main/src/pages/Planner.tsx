import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Loader2, ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { GoalTracker } from "@/components/GoalTracker";
import { ReadingPlanner } from "@/components/ReadingPlanner";
import { ReadingDiary } from "@/components/ReadingDiary";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";

const Planner = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<{ id: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session?.user) {
        navigate("/auth");
      } else {
        setUser({ id: session.user.id });
      }
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.user) {
        navigate("/auth");
      } else {
        setUser({ id: session.user.id });
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link
            to="/demo"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back to Demo</span>
          </Link>

          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
            My Reading Planner
          </h1>
          <p className="text-muted-foreground mb-8">
            Set goals, plan your reading schedule, and track your progress
          </p>

          <Tabs defaultValue="goals" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 max-w-md">
              <TabsTrigger value="goals">Goals</TabsTrigger>
              <TabsTrigger value="planner">Weekly Plan</TabsTrigger>
              <TabsTrigger value="diary">Diary</TabsTrigger>
            </TabsList>

            <TabsContent value="goals">
              <div className="bg-card rounded-xl border border-border p-6">
                <GoalTracker userId={user.id} />
              </div>
            </TabsContent>

            <TabsContent value="planner">
              <div className="bg-card rounded-xl border border-border p-6">
                <ReadingPlanner userId={user.id} />
              </div>
            </TabsContent>

            <TabsContent value="diary">
              <div className="bg-card rounded-xl border border-border p-6">
                <ReadingDiary userId={user.id} />
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Planner;
