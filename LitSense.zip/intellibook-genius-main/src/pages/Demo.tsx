import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Search, Filter, Loader2, Sparkles, ArrowLeft, GitCompare, Brain, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BookCard, BookData } from "@/components/BookCard";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import { BookComparisonTool } from "@/components/BookComparisonTool";
import { supabase } from "@/integrations/supabase/client";
import { useBookHistory } from "@/hooks/useBookHistory";
import { ReadingAnalysisModal } from "@/components/ReadingAnalysisModal";
import { VoiceQueryButton } from "@/components/VoiceQueryButton";
import { LanguageSelector, Language, translations } from "@/components/LanguageSelector";

const genres = [
  "All Genres",
  "Fiction",
  "Mystery",
  "Science Fiction",
  "Romance",
  "Fantasy",
  "Biography",
  "Self-Help",
  "History",
  "Thriller",
];

const exampleQueries = [
  "A heartwarming story about family and forgiveness",
  "Sci-fi adventure with time travel elements",
  "Mystery set in a small coastal town",
  "Self-improvement book for entrepreneurs",
];

const Demo = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { saveSearchHistory, updateBookRating, getUserSearchHistory } = useBookHistory();

  const [query, setQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All Genres");
  const [isLoading, setIsLoading] = useState(false);
  const [books, setBooks] = useState<BookData[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [selectedBooksForComparison, setSelectedBooksForComparison] = useState<BookData[]>([]);
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [userHistory, setUserHistory] = useState<string[]>([]);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [language, setLanguage] = useState<Language>("en");
  const t = translations[language];

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);
      const history = await getUserSearchHistory();
      setUserHistory(history);
      setAuthLoading(false);
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const searchBooks = async () => {
    if (!query.trim()) {
      toast({
        title: t.pleaseEnterQuery,
        description: t.describeWhatLooking,
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setHasSearched(true);

    try {
      let searchQuery = query;
      if (selectedGenre !== "All Genres") {
        searchQuery += `+subject:${selectedGenre.toLowerCase()}`;
      }

      const response = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(
          searchQuery
        )}&maxResults=8&orderBy=relevance`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch books");
      }

      const data = await response.json();

      if (!data.items || data.items.length === 0) {
        setBooks([]);
        toast({
          title: "No books found",
          description: "Try a different search query or genre.",
        });
        return;
      }

      const transformedBooks: BookData[] = data.items.map(
        (item: any) => ({
          id: item.id,
          title: item.volumeInfo.title || "Unknown Title",
          author: item.volumeInfo.authors?.join(", ") || "Unknown Author",
          genre:
            item.volumeInfo.categories?.[0] || selectedGenre || "General",
          description:
            item.volumeInfo.description?.slice(0, 200) + "..." ||
            "No description available.",
          thumbnail: item.volumeInfo.imageLinks?.thumbnail?.replace(
            "http:",
            "https:"
          ),
          rating: item.volumeInfo.averageRating || 3.5 + Math.random() * 1.5,
          reason: generateReason(query, item.volumeInfo),
          pageCount: item.volumeInfo.pageCount,
          publishedDate: item.volumeInfo.publishedDate,
          publisher: item.volumeInfo.publisher,
          query: query,
        })
      );

      setBooks(transformedBooks);
      
      // Save to history
      await saveSearchHistory(query, selectedGenre, transformedBooks);
      
      toast({
        title: t.recommendations,
        description: t.booksFound.replace("{count}", String(transformedBooks.length)),
      });
    } catch (error) {
      console.error("Error fetching books:", error);
      toast({
        title: "Error fetching recommendations",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateReason = (userQuery: string, bookInfo: any): string => {
    const reasons = [
      `Matches your interest in ${
        bookInfo.categories?.[0]?.toLowerCase() || "this genre"
      }`,
      `Highly rated by readers with similar preferences`,
      `Themes align with "${userQuery.slice(0, 30)}..."`,
      `Popular choice for readers seeking ${
        bookInfo.categories?.[0] || "engaging reads"
      }`,
      `Recommended based on semantic similarity to your query`,
    ];
    return reasons[Math.floor(Math.random() * reasons.length)];
  };

  const handleExampleClick = (example: string) => {
    setQuery(example);
  };

  const handleRating = async (bookId: string, rating: number) => {
    if (user) {
      await updateBookRating(bookId, user.id, rating);
    }
  };

  const toggleBookForComparison = (book: BookData) => {
    setSelectedBooksForComparison((prev) => {
      const isAlreadySelected = prev.find((b) => b.id === book.id);
      if (isAlreadySelected) {
        return prev.filter((b) => b.id !== book.id);
      }
      if (prev.length >= 2) {
        toast({
          title: "Maximum 2 books",
          description: "Remove one book before adding another.",
        });
        return prev;
      }
      return [...prev, book];
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link
              to="/"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <h1 className="font-display text-xl md:text-2xl font-bold text-foreground">
              Book Recommendation Demo
            </h1>
            <div className="flex items-center gap-2">
              <LanguageSelector value={language} onChange={setLanguage} />
              <Link to="/planner">
                <Button variant="outline" size="sm" className="gap-2">
                  <CalendarDays className="w-4 h-4" />
                  <span className="hidden sm:inline">Planner</span>
                </Button>
              </Link>
              <Button
                onClick={() => setShowAnalysis(true)}
                variant="outline"
                size="sm"
                className="gap-2"
              >
                <Brain className="w-4 h-4" />
                <span className="hidden sm:inline">Reading Analysis</span>
                <span className="sm:hidden">Analysis</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Search Interface */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto mb-8"
        >
          <div className="bg-card rounded-2xl p-6 md:p-8 border border-border/50 shadow-lg">
            <h2 className="font-display text-2xl font-bold text-foreground mb-4 text-center">
              {t.findBook}
            </h2>
            <p className="text-muted-foreground text-center mb-6">
              {t.describeBook}
            </p>

            {/* Query Input with Voice */}
            <div className="relative mb-4">
              <Search className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-12 pr-14 py-4 bg-background border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                rows={3}
              />
              <div className="absolute right-3 top-3">
                <VoiceQueryButton onTranscript={(text) => setQuery(text)} disabled={isLoading} />
              </div>
            </div>

            {/* Example Queries */}
            <div className="mb-6">
              <p className="text-sm text-muted-foreground mb-2">{t.tryExample}</p>
              <div className="flex flex-wrap gap-2">
                {exampleQueries.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleExampleClick(example)}
                    className="px-3 py-1.5 text-xs bg-secondary rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>

            {/* Genre Filter */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex-1">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-2">
                  <Filter className="w-4 h-4" />
                  {t.genreFilter}
                </label>
                <select
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                >
                  {genres.map((genre) => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Search Button */}
            <Button
              onClick={searchBooks}
              disabled={isLoading}
              variant="hero"
              size="lg"
              className="w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {t.finding}
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  {t.getRecommendations}
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Comparison Toggle */}
        {books.length >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto mb-6"
          >
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card rounded-xl p-4 border border-border/50">
              <div className="flex items-center gap-2">
                <GitCompare className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground">
                  Compare Books ({selectedBooksForComparison.length}/2 selected)
                </span>
              </div>
              <Button
                onClick={() => setShowComparison(true)}
                disabled={selectedBooksForComparison.length !== 2}
                variant="accent"
                size="sm"
              >
                Compare Selected
              </Button>
            </div>
          </motion.div>
        )}

        {/* Results */}
        {hasSearched && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {books.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 max-w-7xl mx-auto">
                {books.map((book, index) => (
                  <div key={book.id} className="relative">
                    <BookCard 
                      book={book} 
                      index={index} 
                      onRate={handleRating}
                      showXAI={true}
                      userHistory={userHistory}
                    />
                    <button
                      onClick={() => toggleBookForComparison(book)}
                      className={`absolute top-2 right-2 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                        selectedBooksForComparison.find((b) => b.id === book.id)
                          ? "bg-primary text-primary-foreground"
                          : "bg-background/80 text-muted-foreground hover:bg-primary/20"
                      }`}
                    >
                      <GitCompare className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              !isLoading && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">{t.noBooks}</p>
                </div>
              )
            )}
          </motion.div>
        )}
      </div>

      {/* Comparison Modal */}
      {showComparison && selectedBooksForComparison.length === 2 && (
        <BookComparisonTool
          book1={selectedBooksForComparison[0]}
          book2={selectedBooksForComparison[1]}
          onClose={() => setShowComparison(false)}
        />
      )}

      {/* Reading Analysis Modal */}
      <ReadingAnalysisModal 
        open={showAnalysis} 
        onOpenChange={setShowAnalysis} 
      />
    </div>
  );
};

export default Demo;
