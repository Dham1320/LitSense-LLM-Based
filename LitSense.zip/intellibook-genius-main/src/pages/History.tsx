import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { History, Search, Book, Calendar, Trash2, ArrowLeft, Clock } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/StarRating";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SearchHistoryItem {
  id: string;
  query: string;
  genre: string | null;
  created_at: string;
  books: BookHistoryItem[];
}

interface BookHistoryItem {
  id: string;
  book_id: string;
  title: string;
  author: string;
  genre: string | null;
  thumbnail: string | null;
  rating: number;
  user_rating: number | null;
  reason: string | null;
  created_at: string;
}

const HistoryPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);
      fetchHistory(session.user.id);
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchHistory = async (userId: string) => {
    try {
      // Fetch search history
      const { data: searches, error: searchError } = await supabase
        .from("user_search_history")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      if (searchError) throw searchError;

      if (!searches || searches.length === 0) {
        setHistory([]);
        setLoading(false);
        return;
      }

      // Fetch book history for each search
      const { data: books, error: bookError } = await supabase
        .from("user_book_history")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      if (bookError) throw bookError;

      // Group books by search_id
      const historyWithBooks: SearchHistoryItem[] = searches.map((search) => ({
        id: search.id,
        query: search.query,
        genre: search.genre,
        created_at: search.created_at,
        books: (books || []).filter((book) => book.search_id === search.id),
      }));

      setHistory(historyWithBooks);
    } catch (error) {
      console.error("Error fetching history:", error);
      toast({
        title: "Error loading history",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteSearchHistory = async (searchId: string) => {
    try {
      const { error } = await supabase
        .from("user_search_history")
        .delete()
        .eq("id", searchId);

      if (error) throw error;

      setHistory((prev) => prev.filter((item) => item.id !== searchId));
      toast({
        title: "Search deleted",
        description: "Your search history has been updated.",
      });
    } catch (error) {
      console.error("Error deleting search:", error);
      toast({
        title: "Error deleting search",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-primary/10 rounded-full">
                <History className="w-6 h-6 text-primary" />
              </div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground">
                Your Reading History
              </h1>
            </div>
            <p className="text-muted-foreground">
              View your past searches and recommended books
            </p>
          </motion.div>

          {/* History Content */}
          {history.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <div className="p-4 bg-secondary/50 rounded-full w-fit mx-auto mb-4">
                <Clock className="w-12 h-12 text-muted-foreground" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">
                No history yet
              </h2>
              <p className="text-muted-foreground mb-6">
                Start exploring books to build your reading history
              </p>
              <Button onClick={() => navigate("/demo")} variant="hero">
                Try the Demo
              </Button>
            </motion.div>
          ) : (
            <div className="space-y-8">
              {history.map((search, index) => (
                <motion.div
                  key={search.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl border border-border/50 overflow-hidden"
                >
                  {/* Search Header */}
                  <div className="p-4 md:p-6 bg-secondary/30 border-b border-border/50">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Search className="w-4 h-4 text-primary" />
                          <span className="text-sm font-medium text-foreground">
                            Search Query
                          </span>
                          {search.genre && (
                            <span className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full">
                              {search.genre}
                            </span>
                          )}
                        </div>
                        <p className="text-foreground font-medium">
                          "{search.query}"
                        </p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          {formatDate(search.created_at)}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteSearchHistory(search.id)}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Books */}
                  {search.books.length > 0 ? (
                    <div className="p-4 md:p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Book className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {search.books.length} book{search.books.length !== 1 ? "s" : ""} recommended
                        </span>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                        {search.books.map((book) => (
                          <div
                            key={book.id}
                            className="flex gap-3 p-3 bg-secondary/30 rounded-lg"
                          >
                            {book.thumbnail ? (
                              <img
                                src={book.thumbnail}
                                alt={book.title}
                                className="w-12 h-18 object-cover rounded"
                              />
                            ) : (
                              <div className="w-12 h-18 bg-secondary rounded flex items-center justify-center">
                                <Book className="w-6 h-6 text-muted-foreground" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <h4 className="text-sm font-medium text-foreground line-clamp-1">
                                {book.title}
                              </h4>
                              <p className="text-xs text-muted-foreground line-clamp-1">
                                {book.author}
                              </p>
                              <div className="mt-1">
                                <StarRating rating={book.rating} size="xs" />
                              </div>
                              {book.user_rating && (
                                <p className="text-xs text-primary mt-1">
                                  Your rating: {book.user_rating}/5
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 text-center text-muted-foreground text-sm">
                      No books were saved for this search
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default HistoryPage;
