import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { PersonalizedRecommendations } from "@/components/PersonalizedRecommendations";
import { FlashcardGenerator } from "@/components/FlashcardGenerator";
import { AIBookComparison } from "@/components/AIBookComparison";
import { LearningTwinProfile } from "@/components/LearningTwinProfile";
import { 
  Target, 
  BookOpen, 
  Calendar, 
  TrendingUp, 
  Clock, 
  Award,
  Search,
  Plus,
  ArrowRight,
  Flame,
  BookMarked
} from "lucide-react";

interface Goal {
  id: string;
  goal_title: string;
  target_books: number;
  completed_books: number;
  target_date: string;
  status: string;
}

interface RecentActivity {
  id: string;
  book_title: string;
  pages_read: number;
  time_spent_minutes: number;
  entry_date: string;
}

interface UserProfile {
  full_name: string;
  primary_goal: string;
  daily_reading_time: number;
  academic_level: string;
  course_domain?: string;
  study_focus?: string;
}

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [stats, setStats] = useState({
    totalBooksRead: 0,
    totalPagesRead: 0,
    totalMinutesRead: 0,
    currentStreak: 0
  });
  const navigate = useNavigate();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        navigate("/auth");
      }
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        navigate("/auth");
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;

    const { data: goalsData } = await supabase
      .from("reading_goals")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(3);

    if (goalsData) setGoals(goalsData);

    const { data: diaryData } = await supabase
      .from("reading_diary")
      .select("id, book_title, pages_read, time_spent_minutes, entry_date")
      .eq("user_id", user.id)
      .order("entry_date", { ascending: false })
      .limit(5);

    if (diaryData) setRecentActivity(diaryData);

    const { data: profileData } = await supabase
      .from("user_profiles")
      .select("full_name, primary_goal, daily_reading_time, academic_level, course_domain, study_focus")
      .eq("user_id", user.id)
      .single();

    if (profileData) setProfile(profileData);

    const { data: allDiary } = await supabase
      .from("reading_diary")
      .select("pages_read, time_spent_minutes, entry_date")
      .eq("user_id", user.id);

    if (allDiary) {
      const totalPages = allDiary.reduce((sum, entry) => sum + (entry.pages_read || 0), 0);
      const totalMinutes = allDiary.reduce((sum, entry) => sum + (entry.time_spent_minutes || 0), 0);
      
      const sortedDates = [...new Set(allDiary.map(e => e.entry_date))].sort().reverse();
      let streak = 0;
      const today = new Date().toISOString().split('T')[0];
      
      for (let i = 0; i < sortedDates.length; i++) {
        const expectedDate = new Date();
        expectedDate.setDate(expectedDate.getDate() - i);
        const expected = expectedDate.toISOString().split('T')[0];
        
        if (sortedDates[i] === expected || (i === 0 && sortedDates[0] === today)) {
          streak++;
        } else if (i === 0 && sortedDates[0] !== today) {
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          if (sortedDates[0] === yesterday.toISOString().split('T')[0]) {
            streak++;
          } else {
            break;
          }
        } else {
          break;
        }
      }

      setStats({
        totalBooksRead: goals.filter(g => g.status === 'completed').length,
        totalPagesRead: totalPages,
        totalMinutesRead: totalMinutes,
        currentStreak: streak
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-12">
        <div className="container mx-auto px-4 max-w-7xl">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
              {greeting()}, {profile?.full_name || "Reader"} 👋
            </h1>
            <p className="text-muted-foreground">
              {profile?.primary_goal ? `Working towards: ${profile.primary_goal}` : "Ready to continue your reading journey?"}
            </p>
          </motion.div>

          {/* Learning Twin - Full width at top */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-6"
          >
            <LearningTwinProfile userId={user?.id || ""} />
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6"
          >
            <div className="dashboard-card p-5">
              <div className="flex items-center gap-3">
                <div className="icon-circle w-11 h-11">
                  <Flame className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.currentStreak}</p>
                  <p className="text-xs text-muted-foreground">Day Streak</p>
                </div>
              </div>
            </div>

            <div className="dashboard-card p-5">
              <div className="flex items-center gap-3">
                <div className="icon-circle-accent w-11 h-11">
                  <BookOpen className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.totalPagesRead}</p>
                  <p className="text-xs text-muted-foreground">Pages Read</p>
                </div>
              </div>
            </div>

            <div className="dashboard-card p-5">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, hsl(210 65% 60% / 0.15) 0%, hsl(210 65% 60% / 0.25) 100%)' }}>
                  <Clock className="w-5 h-5 text-accent-blue" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{Math.round(stats.totalMinutesRead / 60)}h</p>
                  <p className="text-xs text-muted-foreground">Time Reading</p>
                </div>
              </div>
            </div>

            <div className="dashboard-card p-5">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, hsl(45 90% 50% / 0.15) 0%, hsl(45 90% 50% / 0.25) 100%)' }}>
                  <Award className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{goals.filter(g => g.status === 'completed').length}</p>
                  <p className="text-xs text-muted-foreground">Goals Done</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* AI Features - 4 column grid */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6"
          >
            <div className="min-h-[380px]">
              <PersonalizedRecommendations userId={user?.id || ""} profile={profile} />
            </div>
            <div className="min-h-[380px]">
              <FlashcardGenerator />
            </div>
            <div className="min-h-[380px]">
              <AIBookComparison />
            </div>
            {/* Quick Actions Card */}
            <div className="dashboard-card flex flex-col min-h-[380px]">
              <div className="p-5 pb-3 border-b border-border/50">
                <div className="flex items-center gap-2 mb-1">
                  <div className="icon-circle w-8 h-8">
                    <TrendingUp className="w-4 h-4 text-primary" />
                  </div>
                  <h3 className="font-semibold text-base text-foreground">Quick Actions</h3>
                </div>
                <p className="text-xs text-muted-foreground">Jump to your tools</p>
              </div>
              <div className="flex-1 p-5 flex flex-col justify-center space-y-3">
                <Link to="/demo" className="block">
                  <Button variant="outline" className="w-full justify-between rounded-xl border-border/60 hover:bg-secondary/60 h-12">
                    <span className="flex items-center gap-2.5">
                      <Search className="w-4 h-4 text-primary" />
                      <span className="font-medium">Find Books</span>
                    </span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link to="/planner" className="block">
                  <Button variant="outline" className="w-full justify-between rounded-xl border-border/60 hover:bg-secondary/60 h-12">
                    <span className="flex items-center gap-2.5">
                      <Calendar className="w-4 h-4 text-primary" />
                      <span className="font-medium">Reading Planner</span>
                    </span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link to="/history" className="block">
                  <Button variant="outline" className="w-full justify-between rounded-xl border-border/60 hover:bg-secondary/60 h-12">
                    <span className="flex items-center gap-2.5">
                      <BookOpen className="w-4 h-4 text-primary" />
                      <span className="font-medium">Book History</span>
                    </span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>

          {/* Goals & Recent Activity */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Goals Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="lg:col-span-2"
            >
              <div className="dashboard-card">
                <div className="flex items-center justify-between p-5 pb-4 border-b border-border/50">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="icon-circle w-8 h-8">
                        <Target className="w-4 h-4 text-primary" />
                      </div>
                      <h3 className="font-semibold text-base text-foreground">Your Reading Goals</h3>
                    </div>
                    <p className="text-xs text-muted-foreground">Track your progress towards reading goals</p>
                  </div>
                  <Link to="/planner">
                    <Button variant="outline" size="sm" className="rounded-xl">
                      <Plus className="w-4 h-4 mr-1" />
                      Add Goal
                    </Button>
                  </Link>
                </div>
                <div className="p-5">
                  {goals.length === 0 ? (
                    <div className="text-center py-10">
                      <BookMarked className="w-14 h-14 text-muted-foreground/30 mx-auto mb-4" />
                      <p className="text-muted-foreground mb-4">No reading goals yet</p>
                      <Link to="/planner">
                        <Button className="rounded-xl bg-gradient-to-r from-primary to-primary/90">
                          Create Your First Goal
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {goals.map((goal) => {
                        const progress = (goal.completed_books / goal.target_books) * 100;
                        const daysLeft = Math.ceil((new Date(goal.target_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                        
                        return (
                          <div key={goal.id} className="p-4 rounded-2xl bg-secondary/40 border border-border/40">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h4 className="font-medium text-foreground">{goal.goal_title}</h4>
                                <p className="text-sm text-muted-foreground">
                                  {goal.completed_books} of {goal.target_books} books
                                </p>
                              </div>
                              {goal.status === 'completed' ? (
                                <span className="px-3 py-1 text-xs rounded-full bg-accent/20 text-accent font-medium">
                                  Completed ✓
                                </span>
                              ) : (
                                <span className="text-xs text-muted-foreground">
                                  {daysLeft > 0 ? `${daysLeft} days left` : 'Overdue'}
                                </span>
                              )}
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>

            {/* Recent Activity */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="dashboard-card h-full">
                <div className="p-5 pb-4 border-b border-border/50">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="icon-circle w-8 h-8">
                      <Clock className="w-4 h-4 text-primary" />
                    </div>
                    <h3 className="font-semibold text-base text-foreground">Recent Reading</h3>
                  </div>
                  <p className="text-xs text-muted-foreground">Your latest reading sessions</p>
                </div>
                <div className="p-5">
                  {recentActivity.length === 0 ? (
                    <div className="text-center py-8">
                      <BookOpen className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">No reading activity yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {recentActivity.slice(0, 4).map((activity) => (
                        <div 
                          key={activity.id} 
                          className="flex items-start gap-3 p-3 rounded-xl bg-secondary/30 border border-border/30 hover:bg-secondary/50 transition-all"
                        >
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                            <BookOpen className="w-4 h-4 text-primary" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">
                              {activity.book_title}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {activity.pages_read} pages • {activity.time_spent_minutes} min
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Dashboard;
