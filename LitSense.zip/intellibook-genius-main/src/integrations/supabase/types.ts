export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      reading_diary: {
        Row: {
          ai_feedback: string | null
          book_title: string
          created_at: string
          entry_date: string
          id: string
          mood: string | null
          pages_read: number | null
          planner_id: string | null
          struggles: string | null
          time_spent_minutes: number | null
          user_id: string
          what_learned: string | null
        }
        Insert: {
          ai_feedback?: string | null
          book_title: string
          created_at?: string
          entry_date?: string
          id?: string
          mood?: string | null
          pages_read?: number | null
          planner_id?: string | null
          struggles?: string | null
          time_spent_minutes?: number | null
          user_id: string
          what_learned?: string | null
        }
        Update: {
          ai_feedback?: string | null
          book_title?: string
          created_at?: string
          entry_date?: string
          id?: string
          mood?: string | null
          pages_read?: number | null
          planner_id?: string | null
          struggles?: string | null
          time_spent_minutes?: number | null
          user_id?: string
          what_learned?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reading_diary_planner_id_fkey"
            columns: ["planner_id"]
            isOneToOne: false
            referencedRelation: "reading_planner"
            referencedColumns: ["id"]
          },
        ]
      }
      reading_goals: {
        Row: {
          completed_books: number
          created_at: string
          goal_title: string
          id: string
          status: string | null
          target_books: number
          target_date: string
          updated_at: string
          user_id: string
        }
        Insert: {
          completed_books?: number
          created_at?: string
          goal_title: string
          id?: string
          status?: string | null
          target_books?: number
          target_date: string
          updated_at?: string
          user_id: string
        }
        Update: {
          completed_books?: number
          created_at?: string
          goal_title?: string
          id?: string
          status?: string | null
          target_books?: number
          target_date?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      reading_planner: {
        Row: {
          book_author: string | null
          book_title: string
          created_at: string
          goal_id: string | null
          id: string
          pages_to_read: number | null
          planned_date: string
          reading_minutes: number | null
          status: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          book_author?: string | null
          book_title: string
          created_at?: string
          goal_id?: string | null
          id?: string
          pages_to_read?: number | null
          planned_date: string
          reading_minutes?: number | null
          status?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          book_author?: string | null
          book_title?: string
          created_at?: string
          goal_id?: string | null
          id?: string
          pages_to_read?: number | null
          planned_date?: string
          reading_minutes?: number | null
          status?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reading_planner_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "reading_goals"
            referencedColumns: ["id"]
          },
        ]
      }
      user_book_history: {
        Row: {
          author: string
          book_id: string
          created_at: string
          description: string | null
          genre: string | null
          id: string
          page_count: number | null
          published_date: string | null
          publisher: string | null
          rating: number | null
          reason: string | null
          search_id: string | null
          thumbnail: string | null
          title: string
          user_id: string
          user_rating: number | null
        }
        Insert: {
          author: string
          book_id: string
          created_at?: string
          description?: string | null
          genre?: string | null
          id?: string
          page_count?: number | null
          published_date?: string | null
          publisher?: string | null
          rating?: number | null
          reason?: string | null
          search_id?: string | null
          thumbnail?: string | null
          title: string
          user_id: string
          user_rating?: number | null
        }
        Update: {
          author?: string
          book_id?: string
          created_at?: string
          description?: string | null
          genre?: string | null
          id?: string
          page_count?: number | null
          published_date?: string | null
          publisher?: string | null
          rating?: number | null
          reason?: string | null
          search_id?: string | null
          thumbnail?: string | null
          title?: string
          user_id?: string
          user_rating?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "user_book_history_search_id_fkey"
            columns: ["search_id"]
            isOneToOne: false
            referencedRelation: "user_search_history"
            referencedColumns: ["id"]
          },
        ]
      }
      user_profiles: {
        Row: {
          academic_level: string | null
          course_domain: string | null
          created_at: string
          daily_reading_time: number | null
          full_name: string | null
          id: string
          onboarding_completed: boolean | null
          primary_goal: string | null
          reading_difficulty: string | null
          study_focus: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          academic_level?: string | null
          course_domain?: string | null
          created_at?: string
          daily_reading_time?: number | null
          full_name?: string | null
          id?: string
          onboarding_completed?: boolean | null
          primary_goal?: string | null
          reading_difficulty?: string | null
          study_focus?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          academic_level?: string | null
          course_domain?: string | null
          created_at?: string
          daily_reading_time?: number | null
          full_name?: string | null
          id?: string
          onboarding_completed?: boolean | null
          primary_goal?: string | null
          reading_difficulty?: string | null
          study_focus?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_search_history: {
        Row: {
          created_at: string
          genre: string | null
          id: string
          query: string
          user_id: string
        }
        Insert: {
          created_at?: string
          genre?: string | null
          id?: string
          query: string
          user_id: string
        }
        Update: {
          created_at?: string
          genre?: string | null
          id?: string
          query?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
