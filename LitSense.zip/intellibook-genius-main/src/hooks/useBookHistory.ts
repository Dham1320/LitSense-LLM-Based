import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BookData } from "@/components/BookCard";
import { useToast } from "@/hooks/use-toast";

export const useBookHistory = () => {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);

  const saveSearchHistory = async (
    query: string,
    genre: string | null,
    books: BookData[]
  ): Promise<boolean> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return false;

      setSaving(true);

      // Insert search history
      const { data: searchData, error: searchError } = await supabase
        .from("user_search_history")
        .insert({
          user_id: session.user.id,
          query,
          genre: genre === "All Genres" ? null : genre,
        })
        .select()
        .single();

      if (searchError) throw searchError;

      // Insert book history
      if (books.length > 0) {
        const bookRecords = books.map((book) => ({
          user_id: session.user.id,
          search_id: searchData.id,
          book_id: book.id,
          title: book.title,
          author: book.author,
          genre: book.genre,
          description: book.description,
          thumbnail: book.thumbnail || null,
          rating: book.rating,
          reason: book.reason || null,
          page_count: book.pageCount || null,
          published_date: book.publishedDate || null,
          publisher: book.publisher || null,
        }));

        const { error: bookError } = await supabase
          .from("user_book_history")
          .insert(bookRecords);

        if (bookError) throw bookError;
      }

      return true;
    } catch (error) {
      console.error("Error saving history:", error);
      return false;
    } finally {
      setSaving(false);
    }
  };

  const updateBookRating = async (
    bookId: string,
    userId: string,
    rating: number
  ): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from("user_book_history")
        .update({ user_rating: rating })
        .eq("book_id", bookId)
        .eq("user_id", userId);

      if (error) throw error;

      toast({
        title: "Rating saved!",
        description: `You rated this book ${rating} stars.`,
      });
      return true;
    } catch (error) {
      console.error("Error updating rating:", error);
      toast({
        title: "Error saving rating",
        description: "Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };

  const getUserSearchHistory = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return [];

      const { data, error } = await supabase
        .from("user_search_history")
        .select("query")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      return data?.map((item) => item.query) || [];
    } catch (error) {
      console.error("Error fetching search history:", error);
      return [];
    }
  };

  return {
    saving,
    saveSearchHistory,
    updateBookRating,
    getUserSearchHistory,
  };
};
