import { useState } from "react";
import { motion } from "framer-motion";
import { GitCompare, Loader2, Sparkles, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

interface ComparisonResult {
  winner: string;
  winnerReason: string;
  book1Pros: string[];
  book1Cons: string[];
  book2Pros: string[];
  book2Cons: string[];
  recommendation: string;
}

export const AIBookComparison = () => {
  const [book1, setBook1] = useState("");
  const [book2, setBook2] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ComparisonResult | null>(null);

  const compareBooks = async () => {
    if (!book1.trim() || !book2.trim()) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-reading-assistant", {
        body: {
          type: "book_comparison",
          data: {
            book1,
            book2,
          },
        },
      });

      if (error) throw error;
      
      if (data?.comparison) {
        setResult(data.comparison);
      }
    } catch (err) {
      console.error("Error comparing books:", err);
    } finally {
      setLoading(false);
    }
  };

  const resetComparison = () => {
    setResult(null);
    setBook1("");
    setBook2("");
  };

  return (
    <div className="dashboard-card h-full flex flex-col">
      {/* Header */}
      <div className="p-5 pb-3 border-b border-border/50">
        <div className="flex items-center gap-2 mb-1">
          <div className="icon-circle w-8 h-8" style={{ background: 'linear-gradient(135deg, hsl(270 60% 55% / 0.15) 0%, hsl(270 60% 55% / 0.25) 100%)' }}>
            <GitCompare className="w-4 h-4 text-purple-500" />
          </div>
          <h3 className="font-semibold text-base text-foreground">Book vs Book</h3>
        </div>
        <p className="text-xs text-muted-foreground">AI compares and recommends the best fit</p>
      </div>

      {/* Content */}
      <div className="flex-1 p-5 flex flex-col">
        {!result ? (
          <div className="flex-1 flex flex-col justify-center space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Book 1 title..."
                value={book1}
                onChange={(e) => setBook1(e.target.value)}
                className="rounded-xl border-border/60 focus:border-primary/50 bg-secondary/30"
              />
              <Input
                placeholder="Book 2 title..."
                value={book2}
                onChange={(e) => setBook2(e.target.value)}
                className="rounded-xl border-border/60 focus:border-primary/50 bg-secondary/30"
              />
            </div>
            <Button 
              onClick={compareBooks} 
              disabled={loading || !book1.trim() || !book2.trim()}
              className="w-full rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 shadow-md hover:shadow-lg hover:shadow-purple-500/20 transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Comparing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Compare Books
                </>
              )}
            </Button>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex-1 flex flex-col space-y-3 overflow-y-auto"
          >
            {/* Winner banner */}
            <div className="text-center p-4 rounded-2xl bg-gradient-to-br from-purple-500/15 to-purple-600/10 border border-purple-300/30">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-500" />
                <p className="text-xs font-medium text-purple-600 uppercase tracking-wide">Recommended</p>
              </div>
              <p className="font-bold text-lg text-foreground">{result.winner}</p>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{result.winnerReason}</p>
            </div>

            {/* Book comparison */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2 p-3 rounded-xl bg-secondary/40 border border-border/50">
                <div className="flex items-center gap-2 pb-2 border-b border-border/40">
                  <BookOpen className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground truncate">{book1}</span>
                </div>
                <div className="space-y-1.5">
                  {result.book1Pros.slice(0, 2).map((pro, i) => (
                    <p key={i} className="text-xs text-green-600 flex items-start gap-1">
                      <span className="text-green-500 font-bold">+</span>
                      <span>{pro}</span>
                    </p>
                  ))}
                  {result.book1Cons.slice(0, 1).map((con, i) => (
                    <p key={i} className="text-xs text-red-500 flex items-start gap-1">
                      <span className="font-bold">−</span>
                      <span>{con}</span>
                    </p>
                  ))}
                </div>
              </div>
              <div className="space-y-2 p-3 rounded-xl bg-secondary/40 border border-border/50">
                <div className="flex items-center gap-2 pb-2 border-b border-border/40">
                  <BookOpen className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground truncate">{book2}</span>
                </div>
                <div className="space-y-1.5">
                  {result.book2Pros.slice(0, 2).map((pro, i) => (
                    <p key={i} className="text-xs text-green-600 flex items-start gap-1">
                      <span className="text-green-500 font-bold">+</span>
                      <span>{pro}</span>
                    </p>
                  ))}
                  {result.book2Cons.slice(0, 1).map((con, i) => (
                    <p key={i} className="text-xs text-red-500 flex items-start gap-1">
                      <span className="font-bold">−</span>
                      <span>{con}</span>
                    </p>
                  ))}
                </div>
              </div>
            </div>

            {/* Final recommendation */}
            {result.recommendation && (
              <div className="p-3 rounded-xl bg-primary/5 border border-primary/20">
                <p className="text-xs text-muted-foreground leading-relaxed">{result.recommendation}</p>
              </div>
            )}

            <Button 
              variant="outline" 
              size="sm" 
              className="w-full rounded-xl border-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/20" 
              onClick={resetComparison}
            >
              Compare Different Books
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};
