import { Globe } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

export type Language = "en" | "kn" | "hi";

export const languages: { code: Language; name: string; nativeName: string }[] = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "kn", name: "Kannada", nativeName: "ಕನ್ನಡ" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी" },
];

interface LanguageSelectorProps {
  value: Language;
  onChange: (lang: Language) => void;
  className?: string;
}

export const LanguageSelector = ({ value, onChange, className }: LanguageSelectorProps) => {
  return (
    <Select value={value} onValueChange={(val) => onChange(val as Language)}>
      <SelectTrigger className={`w-[140px] ${className}`}>
        <Globe className="w-4 h-4 mr-2" />
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {languages.map((lang) => (
          <SelectItem key={lang.code} value={lang.code}>
            {lang.nativeName}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

// Translation strings
export const translations: Record<Language, Record<string, string>> = {
  en: {
    findBook: "Find Your Perfect Book",
    describeBook: "Describe what you're looking for in natural language",
    searchPlaceholder: "Describe the kind of book you're looking for...",
    tryExample: "Try an example:",
    genreFilter: "Genre Filter (Optional)",
    getRecommendations: "Get Recommendations",
    finding: "Finding your perfect books...",
    noBooks: "No books found. Try a different query.",
    recommendations: "Recommendations ready!",
    booksFound: "Found {count} books.",
    pleaseEnterQuery: "Please enter a query",
    describeWhatLooking: "Describe what kind of book you're looking for.",
  },
  kn: {
    findBook: "ನಿಮ್ಮ ಪರಿಪೂರ್ಣ ಪುಸ್ತಕವನ್ನು ಹುಡುಕಿ",
    describeBook: "ನೀವು ಹುಡುಕುತ್ತಿರುವುದನ್ನು ಸ್ವಾಭಾವಿಕ ಭಾಷೆಯಲ್ಲಿ ವಿವರಿಸಿ",
    searchPlaceholder: "ನೀವು ಹುಡುಕುತ್ತಿರುವ ಪುಸ್ತಕದ ಬಗ್ಗೆ ವಿವರಿಸಿ...",
    tryExample: "ಉದಾಹರಣೆ ಪ್ರಯತ್ನಿಸಿ:",
    genreFilter: "ಪ್ರಕಾರ ಫಿಲ್ಟರ್ (ಐಚ್ಛಿಕ)",
    getRecommendations: "ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ",
    finding: "ನಿಮ್ಮ ಪರಿಪೂರ್ಣ ಪುಸ್ತಕಗಳನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ...",
    noBooks: "ಯಾವುದೇ ಪುಸ್ತಕಗಳು ಕಂಡುಬಂದಿಲ್ಲ. ಬೇರೆ ಪ್ರಶ್ನೆಯನ್ನು ಪ್ರಯತ್ನಿಸಿ.",
    recommendations: "ಶಿಫಾರಸುಗಳು ಸಿದ್ಧವಾಗಿವೆ!",
    booksFound: "{count} ಪುಸ್ತಕಗಳು ಕಂಡುಬಂದಿವೆ.",
    pleaseEnterQuery: "ದಯವಿಟ್ಟು ಪ್ರಶ್ನೆಯನ್ನು ನಮೂದಿಸಿ",
    describeWhatLooking: "ನೀವು ಯಾವ ರೀತಿಯ ಪುಸ್ತಕವನ್ನು ಹುಡುಕುತ್ತಿದ್ದೀರಿ ಎಂದು ವಿವರಿಸಿ.",
  },
  hi: {
    findBook: "अपनी परफेक्ट किताब खोजें",
    describeBook: "आप जो खोज रहे हैं उसे प्राकृतिक भाषा में बताएं",
    searchPlaceholder: "आप किस तरह की किताब खोज रहे हैं बताएं...",
    tryExample: "उदाहरण आज़माएं:",
    genreFilter: "शैली फ़िल्टर (वैकल्पिक)",
    getRecommendations: "सिफारिशें प्राप्त करें",
    finding: "आपकी परफेक्ट किताबें खोज रहे हैं...",
    noBooks: "कोई किताबें नहीं मिलीं। अलग क्वेरी आज़माएं।",
    recommendations: "सिफारिशें तैयार हैं!",
    booksFound: "{count} किताबें मिलीं।",
    pleaseEnterQuery: "कृपया एक प्रश्न दर्ज करें",
    describeWhatLooking: "बताएं कि आप किस तरह की किताब खोज रहे हैं।",
  },
};
