import { motion } from "framer-motion";
import { X, Star, BookOpen, Calendar, Building, FileText } from "lucide-react";
import { BookData } from "./BookCard";
import { Button } from "./ui/button";

interface BookComparisonToolProps {
  book1: BookData;
  book2: BookData;
  onClose: () => void;
}

export const BookComparisonTool = ({ book1, book2, onClose }: BookComparisonToolProps) => {
  const ComparisonRow = ({
    label,
    value1,
    value2,
    icon: Icon,
  }: {
    label: string;
    value1: string | number;
    value2: string | number;
    icon: any;
  }) => (
    <div className="grid grid-cols-3 gap-4 py-3 border-b border-border/50 last:border-0">
      <div className="text-center">
        <p className="text-sm text-foreground">{value1 || "N/A"}</p>
      </div>
      <div className="flex items-center justify-center gap-2">
        <Icon className="w-4 h-4 text-primary" />
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {label}
        </span>
      </div>
      <div className="text-center">
        <p className="text-sm text-foreground">{value2 || "N/A"}</p>
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border p-4 md:p-6 flex items-center justify-between">
          <h2 className="font-display text-xl md:text-2xl font-bold text-foreground">
            Book Comparison
          </h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Book Headers */}
        <div className="grid grid-cols-3 gap-4 p-4 md:p-6 bg-secondary/30">
          <div className="text-center">
            <div className="w-20 h-28 md:w-24 md:h-32 mx-auto mb-3 rounded-lg overflow-hidden bg-muted shadow-md">
              {book1.thumbnail ? (
                <img
                  src={book1.thumbnail}
                  alt={book1.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <BookOpen className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
            </div>
            <h3 className="font-display font-semibold text-foreground text-sm md:text-base line-clamp-2">
              {book1.title}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">{book1.author}</p>
          </div>
          
          <div className="flex items-center justify-center">
            <span className="text-2xl font-bold text-primary">VS</span>
          </div>
          
          <div className="text-center">
            <div className="w-20 h-28 md:w-24 md:h-32 mx-auto mb-3 rounded-lg overflow-hidden bg-muted shadow-md">
              {book2.thumbnail ? (
                <img
                  src={book2.thumbnail}
                  alt={book2.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <BookOpen className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
            </div>
            <h3 className="font-display font-semibold text-foreground text-sm md:text-base line-clamp-2">
              {book2.title}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">{book2.author}</p>
          </div>
        </div>

        {/* Comparison Details */}
        <div className="p-4 md:p-6">
          <ComparisonRow
            label="Genre"
            value1={book1.genre}
            value2={book2.genre}
            icon={BookOpen}
          />
          <ComparisonRow
            label="Rating"
            value1={`${book1.rating.toFixed(1)} ★`}
            value2={`${book2.rating.toFixed(1)} ★`}
            icon={Star}
          />
          <ComparisonRow
            label="Pages"
            value1={book1.pageCount || "Unknown"}
            value2={book2.pageCount || "Unknown"}
            icon={FileText}
          />
          <ComparisonRow
            label="Published"
            value1={book1.publishedDate || "Unknown"}
            value2={book2.publishedDate || "Unknown"}
            icon={Calendar}
          />
          <ComparisonRow
            label="Publisher"
            value1={book1.publisher || "Unknown"}
            value2={book2.publisher || "Unknown"}
            icon={Building}
          />
        </div>

        {/* Descriptions */}
        <div className="p-4 md:p-6 border-t border-border">
          <h3 className="font-display font-semibold text-foreground mb-4 text-center">
            Descriptions
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-secondary/30 rounded-xl p-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                {book1.description}
              </p>
            </div>
            <div className="bg-secondary/30 rounded-xl p-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                {book2.description}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
