import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import {
  Code2,
  Server,
  Brain,
  Database,
  Cloud,
  Palette,
} from "lucide-react";

const techStack = [
  {
    category: "Frontend",
    icon: Palette,
    items: ["React", "TypeScript", "Tailwind CSS", "Framer Motion"],
    color: "bg-blue-500/10 text-blue-600",
  },
  {
    category: "Backend",
    icon: Server,
    items: ["Python", "FastAPI", "Node.js"],
    color: "bg-green-500/10 text-green-600",
  },
  {
    category: "AI/ML",
    icon: Brain,
    items: ["OpenAI GPT", "HuggingFace", "Sentence Transformers"],
    color: "bg-purple-500/10 text-purple-600",
  },
  {
    category: "Vector Database",
    icon: Database,
    items: ["ChromaDB", "FAISS", "Pinecone"],
    color: "bg-orange-500/10 text-orange-600",
  },
  {
    category: "API Integration",
    icon: Code2,
    items: ["Google Books API", "REST APIs", "GraphQL"],
    color: "bg-pink-500/10 text-pink-600",
  },
  {
    category: "Deployment",
    icon: Cloud,
    items: ["Vercel", "AWS", "Heroku", "Docker"],
    color: "bg-cyan-500/10 text-cyan-600",
  },
];

export const TechStackSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-20 md:py-32 bg-secondary/30">
      <div className="container mx-auto px-4" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Technology Stack
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4">
            Built with Modern Tech
          </h2>
          <div className="section-divider" />
          <p className="text-muted-foreground max-w-2xl mx-auto mt-6 text-lg">
            Our system leverages cutting-edge technologies for performance,
            scalability, and intelligent recommendations.
          </p>
        </motion.div>

        {/* Tech Stack Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {techStack.map((tech, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + index * 0.08 }}
              className="bg-card rounded-xl p-6 border border-border/50 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className={`w-10 h-10 rounded-lg ${tech.color} flex items-center justify-center`}
                >
                  <tech.icon className="w-5 h-5" />
                </div>
                <h3 className="font-display font-semibold text-foreground">
                  {tech.category}
                </h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {tech.items.map((item, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 bg-secondary text-sm font-medium text-foreground rounded-full"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
