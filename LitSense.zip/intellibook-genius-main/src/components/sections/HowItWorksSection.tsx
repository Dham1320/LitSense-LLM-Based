import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { MessageSquare, Brain, Database, Sparkles, ArrowRight } from "lucide-react";

const steps = [
  {
    icon: MessageSquare,
    title: "Natural Language Input",
    description:
      "Describe what you're looking for in plain English. No complex filters or categories needed.",
    example: '"I want a thrilling mystery novel set in Victorian London"',
  },
  {
    icon: Brain,
    title: "Text Embeddings",
    description:
      "Your query is converted into semantic vector embeddings that capture the deep meaning of your request.",
    example: "Query → [0.23, -0.45, 0.78, ...]",
  },
  {
    icon: Database,
    title: "Vector Similarity Search",
    description:
      "We search through our book database using cosine similarity to find the most relevant matches.",
    example: "Finding books with similar semantic fingerprints",
  },
  {
    icon: Sparkles,
    title: "LLM Recommendations",
    description:
      "The LLM generates context-aware recommendations with personalized explanations for each suggestion.",
    example: "AI-powered reasoning for each book match",
  },
];

export const HowItWorksSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="how-it-works" className="py-20 md:py-32 bg-background">
      <div className="container mx-auto px-4" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Technical Overview
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4">
            How It Works
          </h2>
          <div className="section-divider" />
          <p className="text-muted-foreground max-w-2xl mx-auto mt-6 text-lg">
            Our recommendation engine combines cutting-edge NLP techniques with
            the Google Books API for real-time, personalized suggestions.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.15 }}
              className="relative"
            >
              <div
                className={`flex flex-col md:flex-row items-center gap-6 md:gap-12 ${
                  index % 2 === 1 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Step Number & Icon */}
                <div className="flex-shrink-0 relative">
                  <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center shadow-lg border border-primary/20">
                    <step.icon className="w-10 h-10 text-primary" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center text-sm shadow-md">
                    {index + 1}
                  </div>
                </div>

                {/* Content */}
                <div
                  className={`flex-1 bg-card rounded-2xl p-6 md:p-8 border border-border/50 shadow-md ${
                    index % 2 === 1 ? "text-right md:text-right" : ""
                  }`}
                >
                  <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">{step.description}</p>
                  <div
                    className={`inline-block px-4 py-2 bg-secondary rounded-lg text-sm font-mono text-accent ${
                      index % 2 === 1 ? "text-right" : ""
                    }`}
                  >
                    {step.example}
                  </div>
                </div>
              </div>

              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden md:flex justify-center py-4">
                  <div className="flex flex-col items-center">
                    <div className="w-0.5 h-8 bg-border" />
                    <ArrowRight className="w-5 h-5 text-primary rotate-90" />
                    <div className="w-0.5 h-8 bg-border" />
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Architecture Diagram Placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16 max-w-4xl mx-auto"
        >
          <div className="bg-card rounded-2xl p-8 border border-border/50 shadow-lg">
            <h3 className="font-display text-xl font-semibold text-foreground text-center mb-6">
              System Architecture
            </h3>
            <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-sm">
              {[
                { label: "User Query", bg: "bg-primary/10", text: "text-primary" },
                { label: "Embedding Model", bg: "bg-accent/10", text: "text-accent" },
                { label: "Vector DB", bg: "bg-secondary", text: "text-foreground" },
                { label: "Google Books API", bg: "bg-primary/10", text: "text-primary" },
                { label: "LLM", bg: "bg-accent/10", text: "text-accent" },
                { label: "Recommendations", bg: "bg-primary/10", text: "text-primary" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div
                    className={`px-4 py-3 rounded-lg ${item.bg} font-medium ${item.text} whitespace-nowrap`}
                  >
                    {item.label}
                  </div>
                  {i < 5 && (
                    <ArrowRight className="w-4 h-4 text-muted-foreground hidden md:block" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
