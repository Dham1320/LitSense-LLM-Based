import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Search, Filter, Loader2, Sparkles, Save } from "lucide-react";
import { Button } from "../ui/button";
import { BookCard, BookData } from "../BookCard";
import { useToast } from "@/hooks/use-toast";
import { useBookHistory } from "@/hooks/useBookHistory";
import { supabase } from "@/integrations/supabase/client";

const genres = [
  "All Genres",
  "Fiction",
  "Mystery",
  "Science Fiction",
  "Romance",
  "Fantasy",
  "Biography",
  "Self-Help",
  "History",
  "Thriller",
];

const exampleQueries = [
  "A heartwarming story about family and forgiveness",
  "Sci-fi adventure with time travel elements",
  "Mystery set in a small coastal town",
  "Self-improvement book for entrepreneurs",
];

export const DemoSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { toast } = useToast();
  const { saveSearchHistory, updateBookRating, getUserSearchHistory } = useBookHistory();

  const [query, setQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All Genres");
  const [isLoading, setIsLoading] = useState(false);
  const [books, setBooks] = useState<BookData[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [userHistory, setUserHistory] = useState<string[]>([]);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      if (session?.user) {
        const history = await getUserSearchHistory();
        setUserHistory(history);
      }
    };
    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user || null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const searchBooks = async () => {
    if (!query.trim()) {
      toast({
        title: "Please enter a query",
        description: "Describe what kind of book you're looking for.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setHasSearched(true);

    try {
      // Build Google Books API query
      let searchQuery = query;
      if (selectedGenre !== "All Genres") {
        searchQuery += `+subject:${selectedGenre.toLowerCase()}`;
      }

      const response = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(
          searchQuery
        )}&maxResults=6&orderBy=relevance`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch books");
      }

      const data = await response.json();

      if (!data.items || data.items.length === 0) {
        setBooks([]);
        toast({
          title: "No books found",
          description: "Try a different search query or genre.",
        });
        return;
      }

      // Transform Google Books API response
      const transformedBooks: BookData[] = data.items.map(
        (item: any) => ({
          id: item.id,
          title: item.volumeInfo.title || "Unknown Title",
          author: item.volumeInfo.authors?.join(", ") || "Unknown Author",
          genre:
            item.volumeInfo.categories?.[0] || selectedGenre || "General",
          description:
            item.volumeInfo.description?.slice(0, 200) + "..." ||
            "No description available.",
          thumbnail: item.volumeInfo.imageLinks?.thumbnail?.replace(
            "http:",
            "https:"
          ),
          rating: item.volumeInfo.averageRating || 3.5 + Math.random() * 1.5,
          reason: generateReason(query, item.volumeInfo),
          pageCount: item.volumeInfo.pageCount,
          publishedDate: item.volumeInfo.publishedDate,
          publisher: item.volumeInfo.publisher,
          query: query, // Pass query for XAI
        })
      );

      setBooks(transformedBooks);

      // Auto-save to history if logged in
      if (user) {
        const saved = await saveSearchHistory(query, selectedGenre, transformedBooks);
        if (saved) {
          toast({
            title: "Recommendations ready!",
            description: `Found ${transformedBooks.length} books. History saved automatically.`,
          });
        } else {
          toast({
            title: "Recommendations ready!",
            description: `Found ${transformedBooks.length} books matching your preferences.`,
          });
        }
      } else {
        toast({
          title: "Recommendations ready!",
          description: `Found ${transformedBooks.length} books. Log in to save your history!`,
        });
      }
    } catch (error) {
      console.error("Error fetching books:", error);
      toast({
        title: "Error fetching recommendations",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateReason = (userQuery: string, bookInfo: any): string => {
    const reasons = [
      `Matches your interest in ${
        bookInfo.categories?.[0]?.toLowerCase() || "this genre"
      }`,
      `Highly rated by readers with similar preferences`,
      `Themes align with "${userQuery.slice(0, 30)}..."`,
      `Popular choice for readers seeking ${
        bookInfo.categories?.[0] || "engaging reads"
      }`,
      `Recommended based on semantic similarity to your query`,
    ];
    return reasons[Math.floor(Math.random() * reasons.length)];
  };

  const handleExampleClick = (example: string) => {
    setQuery(example);
  };

  const handleRating = async (bookId: string, rating: number) => {
    if (user) {
      await updateBookRating(bookId, user.id, rating);
    } else {
      toast({
        title: "Thanks for rating!",
        description: `You rated this book ${rating} stars. Log in to save ratings.`,
      });
    }
  };

  return (
    <section id="demo" className="py-20 md:py-32 bg-secondary/30">
      <div className="container mx-auto px-4" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Interactive Demo
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4">
            Try It Yourself
          </h2>
          <div className="section-divider" />
          <p className="text-muted-foreground max-w-2xl mx-auto mt-6 text-lg">
            Enter your reading preferences in natural language and get
            personalized book recommendations powered by Google Books API.
          </p>
          {user && (
            <p className="text-sm text-primary mt-2">
              <Save className="w-4 h-4 inline mr-1" />
              Logged in - your searches will be saved automatically
            </p>
          )}
        </motion.div>

        {/* Search Interface */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-3xl mx-auto mb-12"
        >
          <div className="bg-card rounded-2xl p-6 md:p-8 border border-border/50 shadow-lg">
            {/* Query Input */}
            <div className="relative mb-4">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Describe the kind of book you're looking for..."
                className="w-full pl-12 pr-4 py-4 bg-background border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                rows={3}
              />
            </div>

            {/* Example Queries */}
            <div className="mb-6">
              <p className="text-sm text-muted-foreground mb-2">
                Try an example:
              </p>
              <div className="flex flex-wrap gap-2">
                {exampleQueries.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleExampleClick(example)}
                    className="px-3 py-1.5 text-xs bg-secondary rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>

            {/* Genre Filter */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex-1">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-2">
                  <Filter className="w-4 h-4" />
                  Genre Filter (Optional)
                </label>
                <select
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                >
                  {genres.map((genre) => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Search Button */}
            <Button
              onClick={searchBooks}
              disabled={isLoading}
              variant="hero"
              size="lg"
              className="w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Finding your perfect books...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Get Recommendations
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Results */}
        {hasSearched && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {books.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 max-w-5xl mx-auto">
                {books.map((book, index) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    index={index}
                    onRate={handleRating}
                    showXAI={true}
                    userHistory={userHistory}
                  />
                ))}
              </div>
            ) : (
              !isLoading && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">
                    No books found. Try a different query.
                  </p>
                </div>
              )
            )}
          </motion.div>
        )}
      </div>
    </section>
  );
};
