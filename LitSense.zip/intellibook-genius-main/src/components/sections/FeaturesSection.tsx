import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import {
  Star,
  Filter,
  History,
  Heart,
  TrendingUp,
  GitCompare,
  Globe,
  Mic,
  UserCheck,
  Briefcase,
} from "lucide-react";

const features = [
  {
    icon: UserCheck,
    title: "Personalized Recommendations",
    description:
      "Recommendations adapt based on your profile preferences, study focus, and reading goals.",
    badge: "Adaptive",
  },
  {
    icon: Briefcase,
    title: "Skill-Based Suggestions",
    description:
      "Get books aligned with career goals like Data Scientist, SDE, or Researcher.",
    badge: "Career",
  },
  {
    icon: Globe,
    title: "Multilingual Support",
    description:
      "Get recommendations in Kannada and other languages. Discover books from around the world.",
    badge: "Global",
  },
  {
    icon: Mic,
    title: "Voice Query",
    description:
      "Speak your preferences naturally using voice input for a hands-free experience.",
    badge: "Accessible",
  },
  {
    icon: Star,
    title: "User Ratings & Reviews",
    description:
      "Rate and review recommended books. Your feedback helps improve future recommendations.",
    badge: "Interactive",
  },
  {
    icon: Filter,
    title: "Advanced Filters",
    description:
      "Filter by genre, language, reading level, and more to narrow down your perfect book.",
    badge: "Customizable",
  },
  {
    icon: Heart,
    title: "Mood-Based Suggestions",
    description:
      "Tell us your reading mood and get books that match your current emotional state.",
    badge: "Unique",
  },
  {
    icon: GitCompare,
    title: "Book Comparison",
    description:
      "Compare two books side by side - summaries, genres, ratings, and reader sentiment.",
    badge: "Analytical",
  },
];

export const FeaturesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="features" className="py-20 md:py-32 bg-background">
      <div className="container mx-auto px-4" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Unique Features
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4">
            Beyond Basic Recommendations
          </h2>
          <div className="section-divider" />
          <p className="text-muted-foreground max-w-2xl mx-auto mt-6 text-lg">
            Our system goes beyond simple suggestions with features designed to
            enhance your book discovery experience.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + index * 0.05 }}
              className="group bg-card rounded-xl p-6 border border-border/50 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <span className="px-2.5 py-1 bg-accent/10 text-accent text-xs font-medium rounded-full">
                  {feature.badge}
                </span>
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
