import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { GraduationCap, BookOpen, Search, Library } from "lucide-react";

const useCases = [
  {
    icon: GraduationCap,
    title: "Students",
    description:
      "Find course-related textbooks, supplementary reading, and research materials based on your study topics.",
    example: '"Physics textbook for undergraduate quantum mechanics"',
  },
  {
    icon: Search,
    title: "Researchers",
    description:
      "Discover academic papers, reference books, and related literature for your research domain.",
    example: '"Machine learning papers on attention mechanisms"',
  },
  {
    icon: BookOpen,
    title: "Casual Readers",
    description:
      "Get personalized fiction and non-fiction recommendations based on your mood and interests.",
    example: '"Something like Harry Potter but for adults"',
  },
  {
    icon: Library,
    title: "Libraries",
    description:
      "Help patrons discover books they'll love and optimize collection recommendations.",
    example: '"Popular new releases in contemporary fiction"',
  },
];

export const UseCasesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container mx-auto px-4" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Use Cases
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mt-3 mb-4">
            Who Can Benefit?
          </h2>
          <div className="section-divider" />
          <p className="text-muted-foreground max-w-2xl mx-auto mt-6 text-lg">
            Our recommendation system serves diverse users with tailored book
            suggestions.
          </p>
        </motion.div>

        {/* Use Cases Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {useCases.map((useCase, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
              className="bg-card rounded-2xl p-8 border border-border/50 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <useCase.icon className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                    {useCase.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {useCase.description}
                  </p>
                  <div className="px-4 py-2 bg-secondary rounded-lg inline-block">
                    <p className="text-sm font-mono text-accent italic">
                      {useCase.example}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
