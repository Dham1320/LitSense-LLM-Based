import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lightbulb, ChevronLeft, ChevronRight, Loader2, Sparkles, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";

interface Flashcard {
  front: string;
  back: string;
}

export const FlashcardGenerator = () => {
  const [bookTitle, setBookTitle] = useState("");
  const [keyIdeas, setKeyIdeas] = useState("");
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [loading, setLoading] = useState(false);

  const generateFlashcards = async () => {
    if (!bookTitle.trim() || !keyIdeas.trim()) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-reading-assistant", {
        body: {
          type: "flashcard_generation",
          data: {
            bookTitle,
            keyIdeas,
          },
        },
      });

      if (error) throw error;
      
      if (data?.flashcards) {
        setFlashcards(data.flashcards);
        setCurrentIndex(0);
        setIsFlipped(false);
      }
    } catch (err) {
      console.error("Error generating flashcards:", err);
    } finally {
      setLoading(false);
    }
  };

  const nextCard = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
    }
  };

  return (
    <div className="dashboard-card h-full flex flex-col">
      {/* Header */}
      <div className="p-5 pb-3 border-b border-border/50">
        <div className="flex items-center gap-2 mb-1">
          <div className="icon-circle w-8 h-8" style={{ background: 'linear-gradient(135deg, hsl(45 90% 50% / 0.15) 0%, hsl(45 90% 50% / 0.25) 100%)' }}>
            <Lightbulb className="w-4 h-4 text-amber-500" />
          </div>
          <h3 className="font-semibold text-base text-foreground">Flashcard Generator</h3>
        </div>
        <p className="text-xs text-muted-foreground">Turn key ideas into revision cards</p>
      </div>

      {/* Content */}
      <div className="flex-1 p-5 flex flex-col">
        {flashcards.length === 0 ? (
          <div className="flex-1 flex flex-col justify-center space-y-3">
            <Input
              placeholder="Book title..."
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              className="rounded-xl border-border/60 focus:border-primary/50 bg-secondary/30"
            />
            <Textarea
              placeholder="Enter key ideas or notes from your reading..."
              value={keyIdeas}
              onChange={(e) => setKeyIdeas(e.target.value)}
              className="min-h-[80px] rounded-xl border-border/60 focus:border-primary/50 bg-secondary/30 resize-none"
            />
            <Button 
              onClick={generateFlashcards} 
              disabled={loading || !bookTitle.trim() || !keyIdeas.trim()}
              className="w-full rounded-xl bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-md hover:shadow-lg transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Flashcards
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Flashcard display */}
            <div 
              className="flex-1 cursor-pointer perspective-1000 min-h-[140px]"
              onClick={() => setIsFlipped(!isFlipped)}
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={isFlipped ? "back" : "front"}
                  initial={{ rotateY: 90, opacity: 0 }}
                  animate={{ rotateY: 0, opacity: 1 }}
                  exit={{ rotateY: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`h-full p-5 rounded-2xl flex items-center justify-center text-center border-2 ${
                    isFlipped 
                      ? "bg-gradient-to-br from-primary/5 to-primary/10 border-primary/30" 
                      : "bg-gradient-to-br from-secondary/60 to-secondary/30 border-border/50"
                  }`}
                >
                  <p className={`text-sm leading-relaxed ${isFlipped ? "text-primary font-medium" : "text-foreground"}`}>
                    {isFlipped ? flashcards[currentIndex].back : flashcards[currentIndex].front}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>
            
            {/* Navigation */}
            <div className="flex items-center justify-between mt-4">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={prevCard}
                disabled={currentIndex === 0}
                className="rounded-full"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              
              {/* Pagination dots */}
              <div className="flex items-center gap-1.5">
                {flashcards.map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      i === currentIndex ? 'bg-primary' : 'bg-muted-foreground/30'
                    }`}
                  />
                ))}
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={nextCard}
                disabled={currentIndex === flashcards.length - 1}
                className="rounded-full"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
            
            <Button 
              variant="outline" 
              className="w-full mt-4 rounded-xl border-primary/30 hover:bg-primary/5"
              onClick={() => {
                setFlashcards([]);
                setBookTitle("");
                setKeyIdeas("");
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
