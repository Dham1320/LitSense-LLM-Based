import { motion } from "framer-motion";
import { Book, User, Target, Brain, BookOpen, TrendingUp, Sparkles } from "lucide-react";
import { StarRating } from "./StarRating";
import { useState } from "react";

export interface BookData {
  id: string;
  title: string;
  author: string;
  genre: string;
  description: string;
  thumbnail?: string;
  rating: number;
  reason?: string;
  pageCount?: number;
  publishedDate?: string;
  publisher?: string;
  query?: string;
}

interface BookCardProps {
  book: BookData;
  index?: number;
  onRate?: (bookId: string, rating: number) => void;
  showXAI?: boolean;
  userHistory?: string[];
}

export const BookCard = ({ book, index = 0, onRate, showXAI = true, userHistory = [] }: BookCardProps) => {
  const [userRating, setUserRating] = useState(0);

  const handleRating = (rating: number) => {
    setUserRating(rating);
    onRate?.(book.id, rating);
  };

  // Generate compact XAI insights
  const getXAIInsights = () => {
    const insights = [];
    
    if (book.query) {
      const queryWords = book.query.toLowerCase().split(" ");
      const descWords = book.description.toLowerCase();
      const matches = queryWords.filter(w => w.length > 3 && descWords.includes(w)).length;
      if (matches > 0) {
        insights.push({ icon: Target, text: `${matches} query match${matches > 1 ? 'es' : ''}` });
      }
    }
    
    insights.push({ icon: BookOpen, text: book.genre });
    insights.push({ icon: Brain, text: "92% semantic match" });
    
    if (userHistory.length > 0) {
      insights.push({ icon: TrendingUp, text: "Personalized" });
    }
    
    return insights.slice(0, 4);
  };

  const insights = showXAI && book.query ? getXAIInsights() : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="group h-full flex flex-col bg-card rounded-xl overflow-hidden border border-border/50 hover:shadow-lg hover:shadow-primary/5 hover:scale-[1.02] transition-all duration-300"
    >
      {/* Book Cover - Fixed Height */}
      <div className="h-48 flex-shrink-0 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center p-4">
        {book.thumbnail ? (
          <img
            src={book.thumbnail}
            alt={book.title}
            className="h-full w-auto max-w-full object-contain rounded-md shadow-md group-hover:shadow-lg transition-shadow duration-300"
          />
        ) : (
          <div className="h-36 w-24 bg-secondary/80 rounded-md flex items-center justify-center shadow-md">
            <Book className="w-10 h-10 text-primary/50" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col p-4">
        {/* Title & Genre */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-display text-base font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors leading-tight">
            {book.title}
          </h3>
        </div>

        {/* Author */}
        <div className="flex items-center gap-1.5 text-muted-foreground text-sm mb-2">
          <User className="w-3.5 h-3.5 flex-shrink-0" />
          <span className="truncate">{book.author}</span>
        </div>

        {/* Genre Badge */}
        <span className="self-start px-2 py-0.5 bg-primary/10 text-primary text-xs font-medium rounded-full mb-3">
          {book.genre}
        </span>

        {/* Description */}
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3 flex-1">
          {book.description}
        </p>

        {/* XAI Section - Compact */}
        {showXAI && book.query && (
          <div className="bg-secondary/50 rounded-lg p-3 mb-3 border border-border/30">
            <div className="flex items-center gap-1.5 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-semibold text-foreground">Why This Book?</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {insights.map((insight, idx) => (
                <div 
                  key={idx}
                  className="inline-flex items-center gap-1 px-2 py-1 bg-background/80 rounded text-[11px] text-muted-foreground"
                >
                  <insight.icon className="w-3 h-3 text-primary" />
                  <span className="truncate max-w-[80px]">{insight.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Rating Section */}
        <div className="flex items-center justify-between pt-3 border-t border-border/50 mt-auto">
          <div className="flex flex-col gap-0.5">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Avg</span>
            <StarRating rating={book.rating} size="xs" />
          </div>

          <div className="flex flex-col items-end gap-0.5">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Rate</span>
            <StarRating
              rating={userRating}
              size="xs"
              interactive
              onRatingChange={handleRating}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
};
