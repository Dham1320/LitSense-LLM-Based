import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, BookOpen, TrendingUp, Target, Sparkles, BarChart3, Heart, Clock, AlertCircle, Loader2, Lightbulb } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";

interface ReadingAnalysisModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface AIAnalysis {
  reader_persona: string;
  key_interests: string[];
  behavior_summary: string;
  strengths: string[];
  gaps: string[];
  improvement_insights: string[];
  reasoning: string;
}

interface AnalysisData {
  totalSearches: number;
  topGenres: { genre: string; count: number }[];
  totalBooks: number;
  avgRating: number;
  recentSearches: string[];
  aiAnalysis: AIAnalysis | null;
}

export const ReadingAnalysisModal = ({ open, onOpenChange }: ReadingAnalysisModalProps) => {
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (open) {
      fetchAnalysis();
    }
  }, [open]);

  const fetchAnalysis = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch search history
      const { data: searches } = await supabase
        .from("user_search_history")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      // Fetch book history
      const { data: books } = await supabase
        .from("user_book_history")
        .select("*")
        .eq("user_id", user.id);

      // Calculate analysis
      const genreCount: Record<string, number> = {};
      books?.forEach(book => {
        if (book.genre) {
          genreCount[book.genre] = (genreCount[book.genre] || 0) + 1;
        }
      });

      const topGenres = Object.entries(genreCount)
        .map(([genre, count]) => ({ genre, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      const ratedBooks = books?.filter(b => b.user_rating && b.user_rating > 0) || [];
      const avgRating = ratedBooks.length > 0
        ? ratedBooks.reduce((acc, b) => acc + (b.user_rating || 0), 0) / ratedBooks.length
        : 0;

      setAnalysis({
        totalSearches: searches?.length || 0,
        topGenres,
        totalBooks: books?.length || 0,
        avgRating: Math.round(avgRating * 10) / 10,
        recentSearches: searches?.slice(0, 5).map(s => s.query) || [],
        aiAnalysis: null,
      });

      // Fetch AI analysis if there's enough data
      if ((searches?.length || 0) > 0 || (books?.length || 0) > 0) {
        setAiLoading(true);
        try {
          const { data: aiData, error } = await supabase.functions.invoke("ai-reading-assistant", {
            body: {
              type: "reading_analysis",
              data: {
                searches: searches?.slice(0, 10).map(s => s.query) || [],
                books: books?.slice(0, 20).map(b => ({ title: b.title, genre: b.genre, rating: b.user_rating })) || [],
                genres: topGenres.map(g => g.genre),
                total_searches: searches?.length || 0,
                books_rated: ratedBooks.length,
                avg_rating: avgRating,
                top_genre: topGenres[0]?.genre || "Unknown",
              },
            },
          });

          if (!error && aiData) {
            setAnalysis(prev => prev ? { ...prev, aiAnalysis: aiData } : null);
          }
        } catch (err) {
          console.error("Error fetching AI analysis:", err);
        } finally {
          setAiLoading(false);
        }
      }
    } catch (error) {
      console.error("Error fetching analysis:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Brain className="w-6 h-6 text-primary" />
            Your Reading Analysis
          </DialogTitle>
          <DialogDescription>
            Deep AI-powered behavioral analysis with explainable insights
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : analysis ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6 pt-4"
          >
            {/* AI Reading Persona */}
            {analysis.aiAnalysis ? (
              <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-5 border border-primary/20">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 bg-primary/20 rounded-lg">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Your Reader Persona</p>
                    <h3 className="text-xl font-display font-bold text-foreground">
                      {analysis.aiAnalysis.reader_persona}
                    </h3>
                  </div>
                </div>
                {analysis.aiAnalysis.key_interests && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {analysis.aiAnalysis.key_interests.map((interest, idx) => (
                      <span key={idx} className="px-2 py-1 bg-primary/10 rounded-full text-xs text-primary">
                        {interest}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ) : aiLoading ? (
              <div className="bg-card rounded-xl p-5 border border-border/50 flex items-center justify-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
                <span className="text-muted-foreground">Generating AI analysis...</span>
              </div>
            ) : null}

            {/* Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { icon: Target, label: "Searches", value: analysis.totalSearches },
                { icon: BookOpen, label: "Books Found", value: analysis.totalBooks },
                { icon: Heart, label: "Avg Rating", value: analysis.avgRating || "—" },
                { icon: BarChart3, label: "Top Genres", value: analysis.topGenres.length },
              ].map((stat, idx) => (
                <div key={idx} className="bg-card rounded-lg p-4 border border-border/50 text-center">
                  <stat.icon className="w-5 h-5 text-primary mx-auto mb-2" />
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Behavior Summary */}
            {analysis.aiAnalysis?.behavior_summary && (
              <div className="bg-card rounded-xl p-5 border border-border/50">
                <h4 className="flex items-center gap-2 font-semibold text-foreground mb-3">
                  <Brain className="w-4 h-4 text-primary" />
                  Reading Behavior Summary
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {analysis.aiAnalysis.behavior_summary}
                </p>
              </div>
            )}

            {/* Strengths & Gaps */}
            {analysis.aiAnalysis && (
              <div className="grid sm:grid-cols-2 gap-4">
                {analysis.aiAnalysis.strengths?.length > 0 && (
                  <div className="bg-green-500/5 rounded-xl p-4 border border-green-500/20">
                    <h4 className="flex items-center gap-2 font-semibold text-green-600 mb-3 text-sm">
                      <TrendingUp className="w-4 h-4" />
                      Strengths
                    </h4>
                    <ul className="space-y-2">
                      {analysis.aiAnalysis.strengths.map((s, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-foreground">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 flex-shrink-0" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {analysis.aiAnalysis.gaps?.length > 0 && (
                  <div className="bg-orange-500/5 rounded-xl p-4 border border-orange-500/20">
                    <h4 className="flex items-center gap-2 font-semibold text-orange-600 mb-3 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      Blind Spots
                    </h4>
                    <ul className="space-y-2">
                      {analysis.aiAnalysis.gaps.map((g, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-foreground">
                          <span className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                          {g}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Top Genres */}
            {analysis.topGenres.length > 0 && (
              <div className="bg-card rounded-xl p-5 border border-border/50">
                <h4 className="flex items-center gap-2 font-semibold text-foreground mb-4">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  Your Top Genres
                </h4>
                <div className="space-y-3">
                  {analysis.topGenres.map((genre, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <span className="text-sm font-medium text-foreground w-24 truncate">
                        {genre.genre}
                      </span>
                      <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${(genre.count / analysis.topGenres[0].count) * 100}%` }}
                          transition={{ delay: idx * 0.1, duration: 0.5 }}
                          className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                        />
                      </div>
                      <span className="text-sm text-muted-foreground w-8">{genre.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* AI Improvement Insights */}
            {analysis.aiAnalysis?.improvement_insights?.length > 0 && (
              <div className="bg-gradient-to-br from-accent/5 to-primary/5 rounded-xl p-5 border border-accent/20">
                <h4 className="flex items-center gap-2 font-semibold text-foreground mb-3">
                  <Lightbulb className="w-4 h-4 text-accent" />
                  AI Improvement Insights
                </h4>
                <ul className="space-y-2">
                  {analysis.aiAnalysis.improvement_insights.map((rec, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent mt-1.5 flex-shrink-0" />
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* AI Reasoning */}
            {analysis.aiAnalysis?.reasoning && (
              <div className="bg-muted/30 rounded-xl p-4 border border-border/50">
                <h4 className="flex items-center gap-2 font-medium text-foreground mb-2 text-sm">
                  <Brain className="w-4 h-4 text-muted-foreground" />
                  How AI Arrived at These Conclusions
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {analysis.aiAnalysis.reasoning}
                </p>
              </div>
            )}

            {/* Recent Searches */}
            {analysis.recentSearches.length > 0 && (
              <div className="bg-card rounded-xl p-5 border border-border/50">
                <h4 className="flex items-center gap-2 font-semibold text-foreground mb-3">
                  <Clock className="w-4 h-4 text-primary" />
                  Recent Searches
                </h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.recentSearches.map((search, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 bg-secondary/50 rounded-full text-sm text-muted-foreground"
                    >
                      {search.length > 30 ? search.slice(0, 30) + "..." : search}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            No reading data available yet. Start searching for books!
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
};
