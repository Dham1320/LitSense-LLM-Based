import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, Trophy, Star, Flame, BookOpen, Target, Zap, Crown, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
}

interface LearningTwinData {
  readerPersona: string;
  topStrengths: string[];
  learningStyle: string;
  totalBooksExplored: number;
  favoriteGenres: string[];
}

interface LearningTwinProfileProps {
  userId: string;
}

const badgeIcons: Record<string, any> = {
  flame: Flame,
  book: BookOpen,
  target: Target,
  star: Star,
  zap: Zap,
  crown: Crown,
  trophy: Trophy,
};

const defaultBadges: Badge[] = [
  { id: "first_book", name: "First Steps", description: "Searched for first book", icon: "book", unlocked: false },
  { id: "streak_7", name: "Week Warrior", description: "7-day reading streak", icon: "flame", unlocked: false, progress: 0, maxProgress: 7 },
  { id: "books_10", name: "Bookworm", description: "Explored 10 books", icon: "target", unlocked: false, progress: 0, maxProgress: 10 },
  { id: "goal_complete", name: "Goal Getter", description: "Completed first goal", icon: "trophy", unlocked: false },
  { id: "pages_100", name: "Page Turner", description: "Read 100 pages", icon: "star", unlocked: false, progress: 0, maxProgress: 100 },
  { id: "streak_30", name: "Dedicated Reader", description: "30-day streak", icon: "crown", unlocked: false, progress: 0, maxProgress: 30 },
];

export const LearningTwinProfile = ({ userId }: LearningTwinProfileProps) => {
  const [twinData, setTwinData] = useState<LearningTwinData | null>(null);
  const [badges, setBadges] = useState<Badge[]>(defaultBadges);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchTwinData();
    }
  }, [userId]);

  const fetchTwinData = async () => {
    setLoading(true);
    try {
      const [searchResult, diaryResult, goalsResult, profileResult] = await Promise.all([
        supabase.from("user_book_history").select("*").eq("user_id", userId),
        supabase.from("reading_diary").select("pages_read, entry_date").eq("user_id", userId),
        supabase.from("reading_goals").select("*").eq("user_id", userId),
        supabase.from("user_profiles").select("*").eq("user_id", userId).single(),
      ]);

      const books = searchResult.data || [];
      const diary = diaryResult.data || [];
      const goals = goalsResult.data || [];
      const profile = profileResult.data;

      const totalBooks = books.length;
      const totalPages = diary.reduce((sum, d) => sum + (d.pages_read || 0), 0);
      const completedGoals = goals.filter(g => g.status === "completed").length;
      
      const uniqueDates = [...new Set(diary.map(d => d.entry_date))].sort().reverse();
      let streak = 0;
      for (let i = 0; i < uniqueDates.length; i++) {
        const expected = new Date();
        expected.setDate(expected.getDate() - i);
        const expectedStr = expected.toISOString().split("T")[0];
        if (uniqueDates[i] === expectedStr) streak++;
        else break;
      }

      const updatedBadges = defaultBadges.map(badge => {
        switch (badge.id) {
          case "first_book":
            return { ...badge, unlocked: totalBooks > 0 };
          case "streak_7":
            return { ...badge, unlocked: streak >= 7, progress: Math.min(streak, 7), maxProgress: 7 };
          case "streak_30":
            return { ...badge, unlocked: streak >= 30, progress: Math.min(streak, 30), maxProgress: 30 };
          case "books_10":
            return { ...badge, unlocked: totalBooks >= 10, progress: Math.min(totalBooks, 10), maxProgress: 10 };
          case "goal_complete":
            return { ...badge, unlocked: completedGoals > 0 };
          case "pages_100":
            return { ...badge, unlocked: totalPages >= 100, progress: Math.min(totalPages, 100), maxProgress: 100 };
          default:
            return badge;
        }
      });

      setBadges(updatedBadges);

      const genreCounts: Record<string, number> = {};
      books.forEach(b => {
        if (b.genre) {
          genreCounts[b.genre] = (genreCounts[b.genre] || 0) + 1;
        }
      });
      const topGenres = Object.entries(genreCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([genre]) => genre);

      let persona = "Curious Explorer";
      if (profile?.primary_goal === "Career advancement") persona = "Career Climber";
      else if (profile?.primary_goal === "Research") persona = "Knowledge Seeker";
      else if (profile?.primary_goal === "Skill development") persona = "Skill Builder";
      else if (profile?.academic_level === "advanced") persona = "Deep Diver";

      let style = "Balanced Learner";
      if (profile?.reading_difficulty === "deep") style = "Comprehensive Reader";
      else if (profile?.reading_difficulty === "light") style = "Quick Learner";
      else if ((profile?.daily_reading_time || 0) >= 60) style = "Marathon Reader";

      setTwinData({
        readerPersona: persona,
        topStrengths: profile?.study_focus ? [profile.study_focus.split(",")[0] || "Learning"] : ["Curious"],
        learningStyle: style,
        totalBooksExplored: totalBooks,
        favoriteGenres: topGenres.length > 0 ? topGenres : ["Exploring..."],
      });

    } catch (err) {
      console.error("Error fetching twin data:", err);
    } finally {
      setLoading(false);
    }
  };

  const unlockedCount = badges.filter(b => b.unlocked).length;

  if (loading) {
    return (
      <div className="dashboard-card p-8 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="dashboard-card overflow-hidden">
      {/* Hero header with gradient */}
      <div className="bg-gradient-to-r from-primary/15 via-purple-500/10 to-accent/10 p-6 pb-4">
        <div className="flex items-center gap-3">
          <div className="icon-circle w-12 h-12">
            <Brain className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-lg text-foreground">Your Learning Twin</h3>
            <p className="text-xs text-muted-foreground">AI profile that evolves with your reading</p>
          </div>
        </div>
      </div>

      {/* Content */}
      {twinData && (
        <div className="p-5 space-y-5">
          {/* Persona highlight */}
          <div className="text-center p-5 rounded-2xl bg-gradient-to-br from-primary/5 via-secondary/50 to-purple-500/5 border border-primary/15">
            <p className="text-xs text-muted-foreground mb-1.5">Reader Persona</p>
            <p className="text-xl font-display font-bold text-primary">{twinData.readerPersona}</p>
            <p className="text-xs text-muted-foreground mt-1">{twinData.learningStyle}</p>
          </div>

          {/* Stats mini-cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-xl bg-gradient-to-br from-secondary/60 to-secondary/30 border border-border/40 text-center">
              <p className="text-2xl font-bold text-foreground">{twinData.totalBooksExplored}</p>
              <p className="text-xs text-muted-foreground mt-0.5">Books Explored</p>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-br from-secondary/60 to-secondary/30 border border-border/40 text-center">
              <p className="text-2xl font-bold text-foreground">{unlockedCount}/{badges.length}</p>
              <p className="text-xs text-muted-foreground mt-0.5">Badges Earned</p>
            </div>
          </div>

          {/* Interest tags */}
          <div>
            <p className="text-xs text-muted-foreground mb-2">Top Interests</p>
            <div className="flex flex-wrap gap-1.5">
              {twinData.favoriteGenres.map((genre, i) => (
                <span 
                  key={i} 
                  className="px-3 py-1.5 text-xs rounded-full bg-primary/10 text-primary font-medium border border-primary/20"
                >
                  {genre}
                </span>
              ))}
            </div>
          </div>

          {/* Badges */}
          <div>
            <p className="text-xs text-muted-foreground mb-2">Badges</p>
            <div className="grid grid-cols-3 gap-2">
              {badges.map((badge, index) => {
                const IconComponent = badgeIcons[badge.icon] || Trophy;
                return (
                  <motion.div
                    key={badge.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className={`relative p-3 rounded-xl text-center transition-all ${
                      badge.unlocked 
                        ? "bg-gradient-to-br from-amber-500/15 to-amber-500/5 border border-amber-500/30" 
                        : "bg-muted/40 border border-border/40 opacity-60"
                    }`}
                    title={badge.description}
                  >
                    <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center ${
                      badge.unlocked ? 'bg-amber-500/20' : 'bg-muted/50'
                    }`}>
                      <IconComponent className={`w-4 h-4 ${badge.unlocked ? "text-amber-500" : "text-muted-foreground"}`} />
                    </div>
                    <p className="text-[10px] mt-1.5 font-medium truncate">{badge.name}</p>
                    {badge.maxProgress && !badge.unlocked && (
                      <div className="h-1 bg-muted rounded-full mt-1.5 overflow-hidden">
                        <div 
                          className="h-full bg-amber-500/60 rounded-full transition-all"
                          style={{ width: `${((badge.progress || 0) / badge.maxProgress) * 100}%` }}
                        />
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
