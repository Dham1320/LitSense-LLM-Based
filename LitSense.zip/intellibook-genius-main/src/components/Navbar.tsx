import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, BookOpen, LogIn, History, CalendarDays } from "lucide-react";
import { Button } from "./ui/button";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";

const navLinks = [
  { href: "#home", label: "Home" },
  { href: "#features", label: "Features" },
  { href: "#team", label: "Team" },
];

const userEmojis = ["📚", "🎓", "📖", "🧠", "✨", "🌟", "💡", "🔥"];

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleNavClick = (href: string) => {
    setIsOpen(false);
    // If on dashboard or other pages, navigate to home first
    if (window.location.pathname !== '/') {
      navigate('/');
      // Wait for navigation then scroll
      setTimeout(() => {
        const element = document.querySelector(href);
        element?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      const element = document.querySelector(href);
      element?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-lg shadow-lg border-b border-border/50"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick("#home");
            }}
            className="flex items-center gap-2 group"
          >
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-semibold text-foreground">
              Lit<span className="text-primary">Sense</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary/50"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <Link to="/dashboard">
                <Button variant="hero" size="sm">
                  Dashboard
                </Button>
              </Link>
            ) : (
              <Link to="/demo">
                <Button variant="hero" size="sm">
                  Try Demo
                </Button>
              </Link>
            )}
            {user && (
              <>
                <Link to="/planner">
                  <Button variant="ghost" size="sm">
                    <CalendarDays className="w-4 h-4 mr-1" />
                    Planner
                  </Button>
                </Link>
                <Link to="/history">
                  <Button variant="ghost" size="sm">
                    <History className="w-4 h-4 mr-1" />
                    History
                  </Button>
                </Link>
              </>
            )}
            {user ? (
              <>
                <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-lg cursor-pointer hover:bg-primary/20 transition-colors" title={user.email}>
                  {userEmojis[user.id.charCodeAt(0) % userEmojis.length]}
                </div>
                <Button variant="heroOutline" size="sm" onClick={handleLogout}>
                  Logout
                </Button>
              </>
            ) : (
              <Link to="/auth">
                <Button variant="heroOutline" size="sm">
                  <LogIn className="w-4 h-4 mr-1" />
                  Login
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-secondary/50 transition-colors"
          >
            {isOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background border-b border-border"
          >
            <div className="container mx-auto px-4 py-4 flex flex-col gap-2">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="px-4 py-3 text-left text-base font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 rounded-lg transition-colors"
                >
                  {link.label}
                </button>
              ))}
              {user ? (
                <Link to="/dashboard" onClick={() => setIsOpen(false)}>
                  <Button variant="hero" className="w-full mt-2">
                    Dashboard
                  </Button>
                </Link>
              ) : (
                <Link to="/demo" onClick={() => setIsOpen(false)}>
                  <Button variant="hero" className="w-full mt-2">
                    Try Demo
                  </Button>
                </Link>
              )}
              {user && (
                <>
                  <Link to="/planner" onClick={() => setIsOpen(false)}>
                    <Button variant="ghost" className="w-full">
                      <CalendarDays className="w-4 h-4 mr-1" />
                      Reading Planner
                    </Button>
                  </Link>
                  <Link to="/history" onClick={() => setIsOpen(false)}>
                    <Button variant="ghost" className="w-full">
                      <History className="w-4 h-4 mr-1" />
                      My History
                    </Button>
                  </Link>
                </>
              )}
              {user ? (
                <Button
                  variant="heroOutline"
                  className="w-full"
                  onClick={() => {
                    handleLogout();
                    setIsOpen(false);
                  }}
                >
                  Logout
                </Button>
              ) : (
                <Link to="/auth" onClick={() => setIsOpen(false)}>
                  <Button variant="heroOutline" className="w-full">
                    <LogIn className="w-4 h-4 mr-1" />
                    Login
                  </Button>
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};
