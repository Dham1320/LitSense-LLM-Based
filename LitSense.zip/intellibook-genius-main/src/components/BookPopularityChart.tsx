import { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";
import { TrendingUp } from "lucide-react";

interface BookPopularityChartProps {
  publishedYear?: string;
  title: string;
}

export const BookPopularityChart = ({ publishedYear, title }: BookPopularityChartProps) => {
  // Generate mock popularity data based on published year
  const popularityData = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const startYear = publishedYear 
      ? parseInt(publishedYear.slice(0, 4)) || currentYear - 10
      : currentYear - 10;
    
    const years = [];
    const yearCount = Math.min(currentYear - startYear + 1, 15);
    
    for (let i = 0; i < yearCount; i++) {
      const year = startYear + i;
      // Simulate popularity curve - peaks around 2-3 years after release then gradual decline
      const yearsFromRelease = i;
      let popularity;
      
      if (yearsFromRelease <= 2) {
        popularity = 40 + yearsFromRelease * 25 + Math.random() * 15;
      } else if (yearsFromRelease <= 5) {
        popularity = 80 - (yearsFromRelease - 2) * 8 + Math.random() * 10;
      } else {
        popularity = Math.max(20, 60 - (yearsFromRelease - 5) * 5 + Math.random() * 15);
      }
      
      years.push({
        year: year.toString(),
        popularity: Math.round(popularity),
        searches: Math.round(popularity * 12 + Math.random() * 100),
      });
    }
    
    return years;
  }, [publishedYear]);

  return (
    <div className="bg-card rounded-xl p-4 border border-border/50">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-4 h-4 text-primary" />
        <h4 className="text-sm font-medium text-foreground">Popularity Over Years</h4>
      </div>
      
      <div className="h-40">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={popularityData}>
            <defs>
              <linearGradient id="popularityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
            <XAxis 
              dataKey="year" 
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              axisLine={{ stroke: "hsl(var(--border))" }}
              tickLine={false}
            />
            <YAxis 
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              axisLine={{ stroke: "hsl(var(--border))" }}
              tickLine={false}
              domain={[0, 100]}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                fontSize: "12px",
              }}
              labelStyle={{ color: "hsl(var(--foreground))" }}
              formatter={(value: number) => [`${value}%`, "Popularity"]}
            />
            <Area
              type="monotone"
              dataKey="popularity"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              fill="url(#popularityGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <p className="text-xs text-muted-foreground mt-2 text-center">
        Based on search trends and reader interest
      </p>
    </div>
  );
};
