import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, BookOpen, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Recommendation {
  title: string;
  author: string;
  reason: string;
  matchScore: number;
}

interface PersonalizedRecommendationsProps {
  userId: string;
  profile: {
    course_domain?: string;
    study_focus?: string;
    primary_goal?: string;
    academic_level?: string;
  } | null;
}

export const PersonalizedRecommendations = ({ userId, profile }: PersonalizedRecommendationsProps) => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRecommendations = async () => {
    if (!profile) return;
    
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke("ai-reading-assistant", {
        body: {
          type: "onboarding_recommendations",
          data: {
            profile: {
              course_domain: profile.course_domain,
              study_focus: profile.study_focus,
              primary_goal: profile.primary_goal,
              academic_level: profile.academic_level,
            },
          },
        },
      });

      if (fnError) throw fnError;

      if (data?.recommendations) {
        setRecommendations(data.recommendations.slice(0, 5));
      }
    } catch (err) {
      console.error("Error fetching recommendations:", err);
      setError("Unable to load recommendations");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (profile && (profile.course_domain || profile.study_focus)) {
      fetchRecommendations();
    }
  }, [profile]);

  if (!profile?.course_domain && !profile?.study_focus) {
    return (
      <div className="dashboard-card p-6 h-full flex flex-col items-center justify-center text-center">
        <div className="icon-circle w-12 h-12 mb-4">
          <Sparkles className="w-6 h-6 text-primary" />
        </div>
        <p className="text-muted-foreground text-sm">
          Complete your profile to get personalized recommendations
        </p>
      </div>
    );
  }

  return (
    <div className="dashboard-card h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-5 pb-3 border-b border-border/50">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="icon-circle w-8 h-8">
              <Sparkles className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-semibold text-base text-foreground">For You</h3>
          </div>
          <p className="text-xs text-muted-foreground">Based on your profile & goals</p>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={fetchRecommendations}
          disabled={loading}
          className="shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0">
        {loading ? (
          <div className="flex items-center justify-center h-full py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-6 px-4">
            <p className="text-sm text-muted-foreground">{error}</p>
            <Button variant="outline" size="sm" className="mt-3 rounded-full" onClick={fetchRecommendations}>
              Try Again
            </Button>
          </div>
        ) : recommendations.length === 0 ? (
          <div className="text-center py-8 px-4">
            <BookOpen className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Click refresh to get recommendations</p>
          </div>
        ) : (
          <ScrollArea className="h-[280px]">
            <div className="p-4 space-y-2">
              {recommendations.map((rec, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.08 }}
                  className="group flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border/40 hover:bg-secondary/60 hover:shadow-sm transition-all cursor-pointer"
                >
                  {/* Book thumbnail placeholder */}
                  <div className="w-10 h-14 rounded-md bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 flex items-center justify-center shrink-0">
                    <BookOpen className="w-4 h-4 text-primary/60" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm text-foreground line-clamp-2 leading-tight mb-0.5">
                      {rec.title}
                    </h4>
                    <p className="text-xs text-muted-foreground">{rec.author}</p>
                  </div>

                  {/* Match badge */}
                  <div className="match-badge shrink-0">
                    {rec.matchScore}%
                  </div>
                </motion.div>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    </div>
  );
};
