import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { CalendarDays, BookOpen, Clock, Check, X, Loader2, Sparkles, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format, addDays, startOfWeek, isSameDay } from "date-fns";

interface PlannerTask {
  id: string;
  book_title: string;
  book_author: string | null;
  planned_date: string;
  reading_minutes: number;
  pages_to_read: number | null;
  status: string;
}

interface ReadingPlannerProps {
  userId: string;
}

export const ReadingPlanner = ({ userId }: ReadingPlannerProps) => {
  const { toast } = useToast();
  const [tasks, setTasks] = useState<PlannerTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [generatingPlan, setGeneratingPlan] = useState(false);
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [newTask, setNewTask] = useState({
    book_title: "",
    book_author: "",
    planned_date: format(new Date(), "yyyy-MM-dd"),
    reading_minutes: 30,
    pages_to_read: 20,
  });

  useEffect(() => {
    fetchTasks();
  }, [userId, currentWeekStart]);

  const fetchTasks = async () => {
    try {
      const weekEnd = addDays(currentWeekStart, 6);
      const { data, error } = await supabase
        .from("reading_planner")
        .select("*")
        .eq("user_id", userId)
        .gte("planned_date", format(currentWeekStart, "yyyy-MM-dd"))
        .lte("planned_date", format(weekEnd, "yyyy-MM-dd"))
        .order("planned_date", { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTask = async () => {
    if (!newTask.book_title) {
      toast({
        title: "Missing book title",
        description: "Please enter a book title.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase.from("reading_planner").insert({
        user_id: userId,
        book_title: newTask.book_title,
        book_author: newTask.book_author || null,
        planned_date: newTask.planned_date,
        reading_minutes: newTask.reading_minutes,
        pages_to_read: newTask.pages_to_read,
        status: "pending",
      });

      if (error) throw error;

      toast({ title: "Reading task added!" });
      setNewTask({
        book_title: "",
        book_author: "",
        planned_date: format(new Date(), "yyyy-MM-dd"),
        reading_minutes: 30,
        pages_to_read: 20,
      });
      fetchTasks();
    } catch (error) {
      console.error("Error adding task:", error);
    }
  };

  const handleUpdateStatus = async (taskId: string, status: string) => {
    try {
      const { error } = await supabase
        .from("reading_planner")
        .update({ status })
        .eq("id", taskId);

      if (error) throw error;
      fetchTasks();
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const generateAIPlan = async () => {
    setGeneratingPlan(true);
    try {
      // Fetch user profile and goals
      const [profileRes, goalsRes] = await Promise.all([
        supabase.from("user_profiles").select("*").eq("user_id", userId).single(),
        supabase.from("reading_goals").select("*").eq("user_id", userId).eq("status", "active").limit(1),
      ]);

      const profile = profileRes.data;
      const goal = goalsRes.data?.[0];

      const { data, error } = await supabase.functions.invoke("ai-reading-assistant", {
        body: {
          type: "planner_generation",
          data: {
            goal_title: goal?.goal_title || "General reading",
            target_books: goal?.target_books || 1,
            daily_reading_time: profile?.daily_reading_time || 30,
            reading_difficulty: profile?.reading_difficulty || "medium",
            current_books: [],
            days_remaining: goal ? Math.ceil((new Date(goal.target_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 30,
          },
        },
      });

      if (error) throw error;

      if (data?.daily_tasks) {
        // Insert generated tasks
        const tasksToInsert = data.daily_tasks.map((task: { day: string; book_title: string; estimated_minutes: number; pages_or_chapters: string }, index: number) => ({
          user_id: userId,
          book_title: task.book_title,
          planned_date: format(addDays(currentWeekStart, index), "yyyy-MM-dd"),
          reading_minutes: task.estimated_minutes || 30,
          pages_to_read: parseInt(task.pages_or_chapters?.match(/\d+/)?.[0] || "20"),
          status: "pending",
        }));

        const { error: insertError } = await supabase.from("reading_planner").insert(tasksToInsert);
        if (insertError) throw insertError;

        toast({
          title: "AI plan generated!",
          description: data.weekly_overview || "Your personalized reading plan is ready.",
        });
        fetchTasks();
      }
    } catch (error) {
      console.error("Error generating plan:", error);
      toast({
        title: "Error generating plan",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setGeneratingPlan(false);
    }
  };

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));

  const getTasksForDay = (date: Date) => {
    return tasks.filter((task) => isSameDay(new Date(task.planned_date), date));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500/20 text-green-600 border-green-500/30";
      case "in_progress": return "bg-blue-500/20 text-blue-600 border-blue-500/30";
      case "skipped": return "bg-red-500/20 text-red-600 border-red-500/30";
      default: return "bg-muted text-muted-foreground border-border";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <CalendarDays className="w-5 h-5 text-primary" />
          Reading Planner
        </h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={generateAIPlan} disabled={generatingPlan}>
            {generatingPlan ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-1" />
                AI Generate Plan
              </>
            )}
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm">Add Task</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Reading Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <Label>Book Title</Label>
                  <Input
                    placeholder="Enter book title"
                    value={newTask.book_title}
                    onChange={(e) => setNewTask({ ...newTask, book_title: e.target.value })}
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label>Author (optional)</Label>
                  <Input
                    placeholder="Author name"
                    value={newTask.book_author}
                    onChange={(e) => setNewTask({ ...newTask, book_author: e.target.value })}
                    className="mt-1.5"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={newTask.planned_date}
                      onChange={(e) => setNewTask({ ...newTask, planned_date: e.target.value })}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label>Minutes</Label>
                    <Input
                      type="number"
                      value={newTask.reading_minutes}
                      onChange={(e) => setNewTask({ ...newTask, reading_minutes: parseInt(e.target.value) || 30 })}
                      className="mt-1.5"
                    />
                  </div>
                </div>
                <Button onClick={handleAddTask} className="w-full">Add Task</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Week Navigation */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => setCurrentWeekStart(addDays(currentWeekStart, -7))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <span className="text-sm font-medium text-foreground">
          {format(currentWeekStart, "MMM d")} - {format(addDays(currentWeekStart, 6), "MMM d, yyyy")}
        </span>
        <Button variant="ghost" size="sm" onClick={() => setCurrentWeekStart(addDays(currentWeekStart, 7))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Week View */}
      <div className="grid grid-cols-7 gap-2">
        {weekDays.map((day) => {
          const dayTasks = getTasksForDay(day);
          const isToday = isSameDay(day, new Date());

          return (
            <div
              key={day.toISOString()}
              className={`min-h-[120px] p-2 rounded-lg border ${
                isToday ? "border-primary bg-primary/5" : "border-border bg-card"
              }`}
            >
              <div className={`text-xs font-medium mb-2 ${isToday ? "text-primary" : "text-muted-foreground"}`}>
                {format(day, "EEE")}
                <span className="block text-foreground">{format(day, "d")}</span>
              </div>
              <div className="space-y-1">
                {dayTasks.map((task) => (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`p-1.5 rounded text-xs border ${getStatusColor(task.status)}`}
                  >
                    <div className="font-medium truncate">{task.book_title}</div>
                    <div className="flex items-center gap-1 mt-1">
                      <Clock className="w-3 h-3" />
                      {task.reading_minutes}m
                    </div>
                    {task.status === "pending" && (
                      <div className="flex gap-1 mt-1">
                        <button
                          onClick={() => handleUpdateStatus(task.id, "completed")}
                          className="p-0.5 hover:bg-green-500/20 rounded"
                        >
                          <Check className="w-3 h-3 text-green-600" />
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(task.id, "skipped")}
                          className="p-0.5 hover:bg-red-500/20 rounded"
                        >
                          <X className="w-3 h-3 text-red-600" />
                        </button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
