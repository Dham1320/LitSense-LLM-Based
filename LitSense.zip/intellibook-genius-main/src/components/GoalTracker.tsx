import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Target, Plus, Calendar, TrendingUp, Trash2, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Goal {
  id: string;
  goal_title: string;
  target_books: number;
  completed_books: number;
  target_date: string;
  status: string;
}

interface GoalTrackerProps {
  userId: string;
}

export const GoalTracker = ({ userId }: GoalTrackerProps) => {
  const { toast } = useToast();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    goal_title: "",
    target_books: 1,
    target_date: "",
  });

  useEffect(() => {
    fetchGoals();
  }, [userId]);

  const fetchGoals = async () => {
    try {
      const { data, error } = await supabase
        .from("reading_goals")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      console.error("Error fetching goals:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddGoal = async () => {
    if (!newGoal.goal_title || !newGoal.target_date) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }

    setIsAddingGoal(true);
    try {
      const { error } = await supabase.from("reading_goals").insert({
        user_id: userId,
        goal_title: newGoal.goal_title,
        target_books: newGoal.target_books,
        target_date: newGoal.target_date,
        status: "active",
      });

      if (error) throw error;

      toast({
        title: "Goal created!",
        description: "Your reading goal has been set.",
      });
      setNewGoal({ goal_title: "", target_books: 1, target_date: "" });
      fetchGoals();
    } catch (error) {
      console.error("Error adding goal:", error);
      toast({
        title: "Error creating goal",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAddingGoal(false);
    }
  };

  const handleDeleteGoal = async (goalId: string) => {
    try {
      const { error } = await supabase
        .from("reading_goals")
        .delete()
        .eq("id", goalId);

      if (error) throw error;

      toast({ title: "Goal deleted" });
      fetchGoals();
    } catch (error) {
      console.error("Error deleting goal:", error);
    }
  };

  const handleUpdateProgress = async (goalId: string, completed: number) => {
    try {
      const goal = goals.find((g) => g.id === goalId);
      if (!goal) return;

      const newStatus = completed >= goal.target_books ? "completed" : "active";

      const { error } = await supabase
        .from("reading_goals")
        .update({ completed_books: completed, status: newStatus })
        .eq("id", goalId);

      if (error) throw error;
      
      if (newStatus === "completed") {
        toast({
          title: "🎉 Goal Completed!",
          description: "Congratulations on reaching your reading goal!",
        });
      }
      fetchGoals();
    } catch (error) {
      console.error("Error updating goal:", error);
    }
  };

  const getDaysRemaining = (targetDate: string) => {
    const target = new Date(targetDate);
    const today = new Date();
    const diff = Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          Reading Goals
        </h3>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-1" />
              New Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set a New Reading Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label>Goal Title</Label>
                <Input
                  placeholder="e.g., Read 12 books in 6 months"
                  value={newGoal.goal_title}
                  onChange={(e) => setNewGoal({ ...newGoal, goal_title: e.target.value })}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label>Number of Books</Label>
                <Input
                  type="number"
                  min="1"
                  value={newGoal.target_books}
                  onChange={(e) => setNewGoal({ ...newGoal, target_books: parseInt(e.target.value) || 1 })}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label>Target Date</Label>
                <Input
                  type="date"
                  value={newGoal.target_date}
                  onChange={(e) => setNewGoal({ ...newGoal, target_date: e.target.value })}
                  className="mt-1.5"
                />
              </div>
              <Button onClick={handleAddGoal} disabled={isAddingGoal} className="w-full">
                {isAddingGoal ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Goal"
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {goals.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <Target className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No reading goals yet. Set your first goal!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {goals.map((goal) => {
            const progress = (goal.completed_books / goal.target_books) * 100;
            const daysRemaining = getDaysRemaining(goal.target_date);
            const isCompleted = goal.status === "completed";

            return (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-xl border ${
                  isCompleted ? "bg-green-500/10 border-green-500/30" : "bg-card border-border"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <TrendingUp className="w-5 h-5 text-primary" />
                    )}
                    <h4 className="font-medium text-foreground">{goal.goal_title}</h4>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteGoal(goal.id)}
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {goal.completed_books} of {goal.target_books} books
                    </span>
                    <span className={`flex items-center gap-1 ${daysRemaining < 7 ? "text-orange-500" : "text-muted-foreground"}`}>
                      <Calendar className="w-4 h-4" />
                      {daysRemaining > 0 ? `${daysRemaining} days left` : "Deadline passed"}
                    </span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                {!isCompleted && (
                  <div className="flex gap-2 mt-3">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateProgress(goal.id, goal.completed_books + 1)}
                      disabled={goal.completed_books >= goal.target_books}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Mark Book Complete
                    </Button>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
