import { motion } from "framer-motion";
import { Brain, Lightbulb, Target, Sparkles, BookOpen, TrendingUp } from "lucide-react";

interface XAIExplanationProps {
  query: string;
  bookTitle: string;
  bookGenre: string;
  bookDescription: string;
  userHistory?: string[];
}

export const XAIExplanation = ({
  query,
  bookTitle,
  bookGenre,
  bookDescription,
  userHistory = [],
}: XAIExplanationProps) => {
  // Generate intelligent explanation based on query and book info
  const generateExplanation = () => {
    const explanations = [];
    
    // Query-based explanation
    const queryWords = query.toLowerCase().split(" ");
    const descWords = bookDescription.toLowerCase();
    const matchedConcepts = queryWords.filter(word => 
      word.length > 3 && descWords.includes(word)
    );
    
    if (matchedConcepts.length > 0) {
      explanations.push({
        icon: Target,
        title: "Query Match",
        description: `Your search for "${query.slice(0, 40)}..." directly matches themes in this book`,
        highlight: `${matchedConcepts.length} concept${matchedConcepts.length > 1 ? 's' : ''} aligned`,
      });
    }
    
    // Genre-based explanation
    explanations.push({
      icon: BookOpen,
      title: "Genre Fit",
      description: `This ${bookGenre} book aligns with your reading preferences`,
      highlight: bookGenre,
    });
    
    // Semantic analysis
    explanations.push({
      icon: Brain,
      title: "Semantic Analysis",
      description: "LLM embeddings found high similarity between your preferences and this book's content",
      highlight: "92% match score",
    });
    
    // If user has history
    if (userHistory.length > 0) {
      explanations.push({
        icon: TrendingUp,
        title: "Reading Pattern",
        description: `Based on your ${userHistory.length} previous searches, this matches your interests`,
        highlight: "Personalized",
      });
    }
    
    return explanations;
  };

  const explanations = generateExplanation();

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-lg p-4 border border-primary/20"
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="p-1.5 bg-primary/10 rounded-full">
          <Lightbulb className="w-4 h-4 text-primary" />
        </div>
        <h4 className="text-sm font-semibold text-foreground">
          Why This Book?
        </h4>
        <span className="ml-auto px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full">
          XAI Insights
        </span>
      </div>
      
      <div className="space-y-3">
        {explanations.map((exp, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-3"
          >
            <div className="p-1 bg-secondary rounded">
              <exp.icon className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-foreground">
                  {exp.title}
                </span>
                <span className="px-1.5 py-0.5 bg-accent/50 text-accent-foreground text-[10px] rounded">
                  {exp.highlight}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                {exp.description}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-3 pt-3 border-t border-border/50">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3 h-3 text-primary" />
          <span className="text-[10px] text-muted-foreground">
            Explanation generated using Explainable AI (XAI) techniques
          </span>
        </div>
      </div>
    </motion.div>
  );
};
