import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, GraduationCap, Target, Clock, Sparkles, ChevronRight, ChevronLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: () => void;
  userId: string;
  userName?: string;
}

const steps = [
  { id: 1, title: "Your Background", icon: GraduationCap },
  { id: 2, title: "Study Focus", icon: BookOpen },
  { id: 3, title: "Your Goals", icon: Target },
  { id: 4, title: "Reading Preferences", icon: Clock },
];

const academicLevels = [
  { value: "beginner", label: "Beginner", description: "New to the subject" },
  { value: "intermediate", label: "Intermediate", description: "Some experience" },
  { value: "advanced", label: "Advanced", description: "Deep expertise" },
];

const readingDifficulties = [
  { value: "light", label: "Light", description: "Easy reads, practical guides" },
  { value: "medium", label: "Medium", description: "Balanced depth & accessibility" },
  { value: "deep", label: "Deep", description: "Technical, comprehensive texts" },
];

const goalTypes = [
  "Career advancement",
  "Exam preparation",
  "Skill development",
  "Personal growth",
  "Research",
  "Hobby learning",
];

export const OnboardingModal = ({ isOpen, onComplete, userId, userName }: OnboardingModalProps) => {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    course_domain: "",
    academic_level: "beginner",
    study_focus: "",
    primary_goal: "",
    daily_reading_time: 30,
    reading_difficulty: "medium",
  });

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const { error } = await supabase.from("user_profiles").upsert({
        user_id: userId,
        full_name: userName,
        ...formData,
        onboarding_completed: true,
      });

      if (error) throw error;

      toast({
        title: "Profile created!",
        description: "We'll now personalize your book recommendations.",
      });
      onComplete();
    } catch (error) {
      console.error("Error saving profile:", error);
      toast({
        title: "Error saving profile",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-foreground">Course / Domain of Study</Label>
              <Input
                placeholder="e.g., Computer Science, Business, Psychology"
                value={formData.course_domain}
                onChange={(e) => setFormData({ ...formData, course_domain: e.target.value })}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label className="text-foreground mb-3 block">Academic Level</Label>
              <div className="grid gap-2">
                {academicLevels.map((level) => (
                  <button
                    key={level.value}
                    onClick={() => setFormData({ ...formData, academic_level: level.value })}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      formData.academic_level === level.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="font-medium text-foreground">{level.label}</div>
                    <div className="text-sm text-muted-foreground">{level.description}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-foreground">Current Study Focus</Label>
              <Textarea
                placeholder="What subjects or skills are you currently learning? e.g., Machine Learning, Web Development, Marketing..."
                value={formData.study_focus}
                onChange={(e) => setFormData({ ...formData, study_focus: e.target.value })}
                className="mt-1.5 min-h-[100px]"
              />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-foreground mb-3 block">Primary Goal</Label>
              <div className="grid grid-cols-2 gap-2">
                {goalTypes.map((goal) => (
                  <button
                    key={goal}
                    onClick={() => setFormData({ ...formData, primary_goal: goal })}
                    className={`p-3 rounded-lg border text-sm transition-all ${
                      formData.primary_goal === goal
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border text-muted-foreground hover:border-primary/50"
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-foreground">Daily Reading Time (minutes)</Label>
              <div className="flex items-center gap-4 mt-1.5">
                <input
                  type="range"
                  min="10"
                  max="120"
                  step="5"
                  value={formData.daily_reading_time}
                  onChange={(e) => setFormData({ ...formData, daily_reading_time: parseInt(e.target.value) })}
                  className="flex-1"
                />
                <span className="text-foreground font-medium w-16">{formData.daily_reading_time} min</span>
              </div>
            </div>
            <div>
              <Label className="text-foreground mb-3 block">Preferred Reading Difficulty</Label>
              <div className="grid gap-2">
                {readingDifficulties.map((diff) => (
                  <button
                    key={diff.value}
                    onClick={() => setFormData({ ...formData, reading_difficulty: diff.value })}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      formData.reading_difficulty === diff.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="font-medium text-foreground">{diff.label}</div>
                    <div className="text-sm text-muted-foreground">{diff.description}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-lg" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <Sparkles className="w-5 h-5 text-primary" />
            Let's Personalize Your Experience
          </DialogTitle>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-6">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                    currentStep >= step.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`w-8 h-0.5 mx-1 ${
                      currentStep > step.id ? "bg-primary" : "bg-muted"
                    }`}
                  />
                )}
              </div>
            );
          })}
        </div>

        <div className="text-sm text-muted-foreground mb-4">
          Step {currentStep} of 4: {steps[currentStep - 1].title}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {renderStep()}
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back
          </Button>
          
          {currentStep < 4 ? (
            <Button onClick={handleNext}>
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  Complete Setup
                  <Sparkles className="w-4 h-4 ml-1" />
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
