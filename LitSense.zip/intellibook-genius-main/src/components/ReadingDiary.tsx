import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { BookOpen, PenLine, Sparkles, Loader2, Calendar, Clock, Brain, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface DiaryEntry {
  id: string;
  book_title: string;
  entry_date: string;
  pages_read: number | null;
  time_spent_minutes: number | null;
  what_learned: string | null;
  struggles: string | null;
  mood: string | null;
  ai_feedback: string | null;
  created_at: string;
}

interface ReadingDiaryProps {
  userId: string;
}

const moods = [
  { value: "motivated", label: "Motivated", emoji: "🔥" },
  { value: "excited", label: "Excited", emoji: "✨" },
  { value: "neutral", label: "Neutral", emoji: "😐" },
  { value: "tired", label: "Tired", emoji: "😴" },
  { value: "frustrated", label: "Frustrated", emoji: "😤" },
];

export const ReadingDiary = ({ userId }: ReadingDiaryProps) => {
  const { toast } = useToast();
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [newEntry, setNewEntry] = useState({
    book_title: "",
    pages_read: 0,
    time_spent_minutes: 30,
    what_learned: "",
    struggles: "",
    mood: "neutral",
  });

  useEffect(() => {
    fetchEntries();
  }, [userId]);

  const fetchEntries = async () => {
    try {
      const { data, error } = await supabase
        .from("reading_diary")
        .select("*")
        .eq("user_id", userId)
        .order("entry_date", { ascending: false })
        .limit(10);

      if (error) throw error;
      setEntries(data || []);
    } catch (error) {
      console.error("Error fetching diary entries:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitEntry = async () => {
    if (!newEntry.book_title) {
      toast({
        title: "Missing book title",
        description: "Please enter the book you're reading.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      // Get AI feedback
      const { data: aiData } = await supabase.functions.invoke("ai-reading-assistant", {
        body: {
          type: "diary_feedback",
          data: newEntry,
        },
      });

      // Insert diary entry with AI feedback
      const { error } = await supabase.from("reading_diary").insert({
        user_id: userId,
        book_title: newEntry.book_title,
        entry_date: format(new Date(), "yyyy-MM-dd"),
        pages_read: newEntry.pages_read,
        time_spent_minutes: newEntry.time_spent_minutes,
        what_learned: newEntry.what_learned || null,
        struggles: newEntry.struggles || null,
        mood: newEntry.mood,
        ai_feedback: aiData ? JSON.stringify(aiData) : null,
      });

      if (error) throw error;

      toast({
        title: "Diary entry saved!",
        description: aiData?.encouragement || "Keep up the great reading habit!",
      });

      setNewEntry({
        book_title: "",
        pages_read: 0,
        time_spent_minutes: 30,
        what_learned: "",
        struggles: "",
        mood: "neutral",
      });
      setIsOpen(false);
      fetchEntries();
    } catch (error) {
      console.error("Error saving diary entry:", error);
      toast({
        title: "Error saving entry",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const parseAIFeedback = (feedback: string | null) => {
    if (!feedback) return null;
    try {
      return JSON.parse(feedback);
    } catch {
      return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <PenLine className="w-5 h-5 text-primary" />
          Reading Diary
        </h3>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <PenLine className="w-4 h-4 mr-1" />
              New Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                Today's Reading Diary
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label>What are you reading?</Label>
                <Input
                  placeholder="Book title"
                  value={newEntry.book_title}
                  onChange={(e) => setNewEntry({ ...newEntry, book_title: e.target.value })}
                  className="mt-1.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Pages Read</Label>
                  <Input
                    type="number"
                    min="0"
                    value={newEntry.pages_read}
                    onChange={(e) => setNewEntry({ ...newEntry, pages_read: parseInt(e.target.value) || 0 })}
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label>Time Spent (minutes)</Label>
                  <Input
                    type="number"
                    min="0"
                    value={newEntry.time_spent_minutes}
                    onChange={(e) => setNewEntry({ ...newEntry, time_spent_minutes: parseInt(e.target.value) || 0 })}
                    className="mt-1.5"
                  />
                </div>
              </div>

              <div>
                <Label>What did you learn?</Label>
                <Textarea
                  placeholder="Key takeaways, insights, or interesting points..."
                  value={newEntry.what_learned}
                  onChange={(e) => setNewEntry({ ...newEntry, what_learned: e.target.value })}
                  className="mt-1.5 min-h-[80px]"
                />
              </div>

              <div>
                <Label>Any struggles or confusion?</Label>
                <Textarea
                  placeholder="Parts that were difficult, questions you have..."
                  value={newEntry.struggles}
                  onChange={(e) => setNewEntry({ ...newEntry, struggles: e.target.value })}
                  className="mt-1.5 min-h-[60px]"
                />
              </div>

              <div>
                <Label className="mb-2 block">How are you feeling?</Label>
                <div className="flex flex-wrap gap-2">
                  {moods.map((mood) => (
                    <button
                      key={mood.value}
                      onClick={() => setNewEntry({ ...newEntry, mood: mood.value })}
                      className={`px-3 py-2 rounded-lg border text-sm transition-all ${
                        newEntry.mood === mood.value
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-border text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      {mood.emoji} {mood.label}
                    </button>
                  ))}
                </div>
              </div>

              <Button onClick={handleSubmitEntry} disabled={submitting} className="w-full">
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Getting AI feedback...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Save & Get AI Feedback
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {entries.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <PenLine className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No diary entries yet. Start recording your reading journey!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {entries.map((entry) => {
            const aiFeedback = parseAIFeedback(entry.ai_feedback);
            const mood = moods.find((m) => m.value === entry.mood);

            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-xl border border-border bg-card"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-foreground flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      {entry.book_title}
                    </h4>
                    <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(entry.entry_date), "MMM d, yyyy")}
                    </p>
                  </div>
                  {mood && (
                    <span className="text-2xl" title={mood.label}>
                      {mood.emoji}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                  {entry.pages_read && (
                    <span className="flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      {entry.pages_read} pages
                    </span>
                  )}
                  {entry.time_spent_minutes && (
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {entry.time_spent_minutes} min
                    </span>
                  )}
                </div>

                {entry.what_learned && (
                  <div className="mb-3">
                    <p className="text-sm text-foreground">{entry.what_learned}</p>
                  </div>
                )}

                {aiFeedback && (
                  <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Brain className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-primary">AI Insights</span>
                    </div>
                    {aiFeedback.learning_summary && (
                      <p className="text-sm text-foreground mb-2">{aiFeedback.learning_summary}</p>
                    )}
                    {aiFeedback.next_task && (
                      <p className="text-sm text-muted-foreground">
                        <strong>Next:</strong> {aiFeedback.next_task}
                      </p>
                    )}
                    {aiFeedback.encouragement && (
                      <p className="text-sm text-primary mt-2 flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        {aiFeedback.encouragement}
                      </p>
                    )}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
