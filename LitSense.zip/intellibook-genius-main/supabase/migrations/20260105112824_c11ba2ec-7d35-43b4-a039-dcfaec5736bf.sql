-- Create user_profiles table for onboarding data
CREATE TABLE public.user_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  course_domain TEXT,
  academic_level TEXT CHECK (academic_level IN ('beginner', 'intermediate', 'advanced')),
  study_focus TEXT,
  primary_goal TEXT,
  daily_reading_time INTEGER DEFAULT 30,
  reading_difficulty TEXT CHECK (reading_difficulty IN ('light', 'medium', 'deep')),
  onboarding_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create reading_goals table
CREATE TABLE public.reading_goals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  goal_title TEXT NOT NULL,
  target_books INTEGER NOT NULL DEFAULT 1,
  completed_books INTEGER NOT NULL DEFAULT 0,
  target_date DATE NOT NULL,
  status TEXT CHECK (status IN ('active', 'completed', 'paused')) DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create reading_planner table for daily/weekly tasks
CREATE TABLE public.reading_planner (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  goal_id UUID REFERENCES public.reading_goals(id) ON DELETE SET NULL,
  book_title TEXT NOT NULL,
  book_author TEXT,
  planned_date DATE NOT NULL,
  reading_minutes INTEGER DEFAULT 30,
  pages_to_read INTEGER,
  status TEXT CHECK (status IN ('pending', 'in_progress', 'completed', 'skipped')) DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create reading_diary table for diary entries
CREATE TABLE public.reading_diary (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  planner_id UUID REFERENCES public.reading_planner(id) ON DELETE SET NULL,
  book_title TEXT NOT NULL,
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  pages_read INTEGER,
  time_spent_minutes INTEGER,
  what_learned TEXT,
  struggles TEXT,
  mood TEXT CHECK (mood IN ('motivated', 'neutral', 'tired', 'frustrated', 'excited')),
  ai_feedback TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_planner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_diary ENABLE ROW LEVEL SECURITY;

-- RLS policies for user_profiles
CREATE POLICY "Users can view their own profile" ON public.user_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own profile" ON public.user_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own profile" ON public.user_profiles FOR UPDATE USING (auth.uid() = user_id);

-- RLS policies for reading_goals
CREATE POLICY "Users can view their own goals" ON public.reading_goals FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own goals" ON public.reading_goals FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own goals" ON public.reading_goals FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own goals" ON public.reading_goals FOR DELETE USING (auth.uid() = user_id);

-- RLS policies for reading_planner
CREATE POLICY "Users can view their own planner" ON public.reading_planner FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own planner tasks" ON public.reading_planner FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own planner tasks" ON public.reading_planner FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own planner tasks" ON public.reading_planner FOR DELETE USING (auth.uid() = user_id);

-- RLS policies for reading_diary
CREATE POLICY "Users can view their own diary" ON public.reading_diary FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own diary entries" ON public.reading_diary FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own diary entries" ON public.reading_diary FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own diary entries" ON public.reading_diary FOR DELETE USING (auth.uid() = user_id);

-- Create trigger function for updated_at (if not exists)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for updated_at
CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_reading_goals_updated_at BEFORE UPDATE ON public.reading_goals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_reading_planner_updated_at BEFORE UPDATE ON public.reading_planner FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();