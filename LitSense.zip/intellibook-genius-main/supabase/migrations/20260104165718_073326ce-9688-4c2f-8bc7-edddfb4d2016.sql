-- Create user_search_history table to store user searches
CREATE TABLE public.user_search_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  genre TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_book_history table to store recommended books
CREATE TABLE public.user_book_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  search_id UUID REFERENCES public.user_search_history(id) ON DELETE CASCADE,
  book_id TEXT NOT NULL,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  genre TEXT,
  description TEXT,
  thumbnail TEXT,
  rating NUMERIC(2,1) DEFAULT 0,
  user_rating INTEGER,
  reason TEXT,
  page_count INTEGER,
  published_date TEXT,
  publisher TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_book_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_search_history
CREATE POLICY "Users can view their own search history" 
ON public.user_search_history 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own search history" 
ON public.user_search_history 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own search history" 
ON public.user_search_history 
FOR DELETE 
USING (auth.uid() = user_id);

-- RLS Policies for user_book_history
CREATE POLICY "Users can view their own book history" 
ON public.user_book_history 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own book history" 
ON public.user_book_history 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own book ratings" 
ON public.user_book_history 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own book history" 
ON public.user_book_history 
FOR DELETE 
USING (auth.uid() = user_id);