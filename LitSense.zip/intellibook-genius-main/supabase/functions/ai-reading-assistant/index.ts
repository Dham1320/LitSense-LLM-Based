import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate JWT authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error("JWT validation failed:", claimsError);
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    console.log("User authenticated:", claimsData.claims.sub);

    const { type, data } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    let systemPrompt = "";
    let userPrompt = "";

    switch (type) {
      case "onboarding_recommendations":
        systemPrompt = `You are an expert book recommendation AI that helps students and learners find the perfect books for their goals.

Based on the user's profile, generate 4 highly relevant book recommendations. For each book:
1. Order from foundational to advanced
2. Match the user's current level and goals
3. Avoid overly difficult books for beginners
4. Prioritize practical impact

Respond in JSON format:
{
  "recommendations": [
    {
      "title": "Book Title",
      "author": "Author Name",
      "reason": "Why this book matches the user's profile (1 sentence)",
      "matchScore": 85
    }
  ]
}`;
        userPrompt = `User Profile:
- Course/Domain: ${data.profile?.course_domain || "General"}
- Academic Level: ${data.profile?.academic_level || "beginner"}
- Study Focus: ${data.profile?.study_focus || "General learning"}
- Primary Goal: ${data.profile?.primary_goal || "Self-improvement"}

Generate 4 personalized book recommendations with match scores (70-98%).`;
        break;

      case "flashcard_generation":
        systemPrompt = `You are an educational AI that creates effective flashcards for learning and retention.

Create 5-8 flashcards from the key ideas provided. Each flashcard should:
1. Have a clear question on the front
2. Have a concise, memorable answer on the back
3. Focus on core concepts, not trivia

Respond in JSON format:
{
  "flashcards": [
    { "front": "Question?", "back": "Answer" }
  ]
}`;
        userPrompt = `Create flashcards from:
Book: ${data.bookTitle}
Key Ideas: ${data.keyIdeas}

Generate effective revision flashcards.`;
        break;

      case "book_comparison":
        systemPrompt = `You are an AI that compares books and recommends the best fit for readers.

Compare the two books and determine which is better suited for the reader. Be objective and fair.

Respond in JSON format:
{
  "comparison": {
    "winner": "Book title that's generally better",
    "winnerReason": "Brief reason (1 sentence)",
    "book1Pros": ["pro1", "pro2"],
    "book1Cons": ["con1"],
    "book2Pros": ["pro1", "pro2"],
    "book2Cons": ["con1"],
    "recommendation": "When to read which (1 sentence)"
  }
}`;
        userPrompt = `Compare these books:
Book 1: ${data.book1}
Book 2: ${data.book2}

Provide a fair comparison with pros, cons, and a winner.`;
        break;

      case "reading_analysis":
        systemPrompt = `You are an AI reading behavior analyst. Analyze the user's reading patterns and provide explainable insights.

Your analysis must be:
1. Based on actual data provided
2. Explainable with clear reasoning
3. Human-readable and constructive
4. No black-box statements

Respond in JSON format:
{
  "reader_persona": "A descriptive title for this type of reader",
  "key_interests": ["interest1", "interest2", "interest3"],
  "behavior_summary": "2-3 sentences about reading patterns",
  "strengths": ["strength1", "strength2"],
  "gaps": ["gap1", "gap2"],
  "improvement_insights": ["actionable insight 1", "actionable insight 2"],
  "reasoning": "Explain how you arrived at these conclusions based on the data"
}`;
        userPrompt = `Analyze this reading behavior:

Search History: ${JSON.stringify(data.searches || [])}
Books Viewed: ${JSON.stringify(data.books || [])}
Genres Explored: ${JSON.stringify(data.genres || [])}
Reading Stats:
- Total Searches: ${data.total_searches || 0}
- Books Rated: ${data.books_rated || 0}
- Average Rating Given: ${data.avg_rating || 0}
- Most Common Genre: ${data.top_genre || "Unknown"}

Provide a deep behavioral analysis with clear reasoning.`;
        break;

      case "planner_generation":
        systemPrompt = `You are an AI reading planner that creates personalized daily/weekly reading schedules.

Based on the user's goals and available time, create a practical reading plan.

Respond in JSON format:
{
  "weekly_overview": "Brief summary of the week's reading focus",
  "daily_tasks": [
    {
      "day": "Monday",
      "book_title": "Book Name",
      "pages_or_chapters": "Pages 1-30 or Chapter 1",
      "estimated_minutes": 30,
      "focus_topic": "What to focus on"
    }
  ],
  "encouragement": "A motivational message for the reader",
  "tips": ["tip1", "tip2"]
}`;
        userPrompt = `Create a reading plan for:
- Goal: ${data.goal_title || "Complete reading goal"}
- Target Books: ${data.target_books || 1}
- Available Time: ${data.daily_reading_time || 30} minutes per day
- Difficulty Preference: ${data.reading_difficulty || "medium"}
- Current Books: ${JSON.stringify(data.current_books || [])}
- Days Until Deadline: ${data.days_remaining || 30}

Generate a practical weekly reading schedule.`;
        break;

      case "diary_feedback":
        systemPrompt = `You are a supportive AI reading companion that provides feedback on diary entries.

Analyze the diary entry and provide:
1. A concise summary of today's learning
2. Identification of any struggles
3. Suggested next reading task
4. Positive, supportive feedback

Respond in JSON format:
{
  "learning_summary": "What the user learned today (2-3 sentences)",
  "struggles_identified": ["struggle1", "struggle2"] or [],
  "next_task": "Specific suggestion for next reading session",
  "encouragement": "Positive, supportive message",
  "insights": "Any insights about reading patterns or progress"
}`;
        userPrompt = `Analyze this diary entry:

Book: ${data.book_title || "Unknown"}
Pages Read: ${data.pages_read || 0}
Time Spent: ${data.time_spent_minutes || 0} minutes
What I Learned: ${data.what_learned || "Not specified"}
Struggles: ${data.struggles || "None mentioned"}
Mood: ${data.mood || "neutral"}

Provide supportive feedback and guidance.`;
        break;

      case "goal_adaptation":
        systemPrompt = `You are an AI that helps adapt reading goals based on progress.

Analyze the user's progress and suggest adaptations to keep them on track.

Respond in JSON format:
{
  "progress_assessment": "How the user is doing (on track, behind, ahead)",
  "adapted_recommendations": ["recommendation1", "recommendation2"],
  "new_books_suggested": [
    {
      "title": "Book Title",
      "reason": "Why this book now"
    }
  ],
  "motivation": "Encouraging message based on progress"
}`;
        userPrompt = `Analyze goal progress:
- Goal: ${data.goal_title || "Reading goal"}
- Target: ${data.target_books || 1} books
- Completed: ${data.completed_books || 0} books
- Days Remaining: ${data.days_remaining || 30}
- Recent Activity: ${JSON.stringify(data.recent_activity || [])}

Provide adaptive recommendations.`;
        break;

      default:
        throw new Error("Invalid request type");
    }

    console.log(`Processing ${type} request`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Usage limit reached. Please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiResponse = await response.json();
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No content in AI response");
    }

    // Try to parse JSON from response
    let parsedContent;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      parsedContent = JSON.parse(jsonStr);
    } catch {
      // If parsing fails, return raw content
      parsedContent = { raw: content };
    }

    console.log(`Successfully processed ${type} request`);

    return new Response(JSON.stringify(parsedContent), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in ai-reading-assistant:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
